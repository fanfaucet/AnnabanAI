import logging
import datetime
from typing import Any, Dict, List, Optional, Set, Tuple
import uuid

from config import config

class Message:
    """Class representing a message in the environment."""
    
    def __init__(self, sender_id: str, content: Any, message_type: str = "general"):
        """Initialize a message with sender, content, and type."""
        self.id = str(uuid.uuid4())
        self.sender_id = sender_id
        self.content = content
        self.message_type = message_type
        self.timestamp = datetime.datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary."""
        return {
            "id": self.id,
            "sender_id": self.sender_id,
            "content": self.content,
            "message_type": self.message_type,
            "timestamp": self.timestamp
        }


class Environment:
    """Enhanced environment for agent interactions."""
    
    def __init__(self):
        """Initialize the environment."""
        self.agents = {}  # agent_id -> agent
        self.agent_names = {}  # agent_name -> agent_id
        self.collectives = {}  # collective_id -> collective
        self.message_history = []
        self.event_listeners = {}  # event_type -> set of agent_ids
        self.resources = {}  # resource_id -> resource
        self.created_at = datetime.datetime.now().isoformat()
        self.logger = logging.getLogger("environment")
        self.logger.info("Environment initialized")
    
    def register_agent(self, agent) -> bool:
        """Register an agent in the environment."""
        if not hasattr(agent, "id") or not hasattr(agent, "name"):
            self.logger.warning("Attempted to register agent without id or name")
            return False
        
        if agent.id in self.agents:
            self.logger.warning(f"Agent with ID {agent.id} is already registered")
            return False
        
        if agent.name in self.agent_names:
            self.logger.warning(f"Agent with name {agent.name} is already registered")
            return False
        
        self.agents[agent.id] = agent
        self.agent_names[agent.name] = agent.id
        
        self.logger.info(f"Registered agent: {agent.name} (ID: {agent.id})")
        return True
    
    def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent from the environment."""
        if agent_id not in self.agents:
            self.logger.warning(f"Agent with ID {agent_id} is not registered")
            return False
        
        agent = self.agents[agent_id]
        del self.agent_names[agent.name]
        del self.agents[agent_id]
        
        # Remove from event listeners
        for listeners in self.event_listeners.values():
            if agent_id in listeners:
                listeners.remove(agent_id)
        
        self.logger.info(f"Unregistered agent: {agent.name} (ID: {agent_id})")
        return True
    
    def register_collective(self, collective) -> bool:
        """Register a collective in the environment."""
        if not hasattr(collective, "id") or not hasattr(collective, "name"):
            self.logger.warning("Attempted to register collective without id or name")
            return False
        
        if collective.id in self.collectives:
            self.logger.warning(f"Collective with ID {collective.id} is already registered")
            return False
        
        self.collectives[collective.id] = collective
        
        self.logger.info(f"Registered collective: {collective.name} (ID: {collective.id})")
        return True
    
    def unregister_collective(self, collective_id: str) -> bool:
        """Unregister a collective from the environment."""
        if collective_id not in self.collectives:
            self.logger.warning(f"Collective with ID {collective_id} is not registered")
            return False
        
        collective = self.collectives[collective_id]
        del self.collectives[collective_id]
        
        self.logger.info(f"Unregistered collective: {collective.name} (ID: {collective_id})")
        return True
    
    def broadcast(self, sender_id: str, content: Any, message_type: str = "general") -> None:
        """Broadcast a message to all agents."""
        if sender_id not in self.agents and sender_id != "system":
            self.logger.warning(f"Broadcast attempted from unregistered sender: {sender_id}")
            return
        
        # Check if broadcasting is enabled
        if not config.get("environment.broadcast_enabled", True):
            self.logger.info("Broadcasting is disabled in configuration")
            return
        
        message = Message(sender_id, content, message_type)
        self.message_history.append(message)
        
        sender_name = "System" if sender_id == "system" else self.agents[sender_id].name
        
        for agent_id, agent in self.agents.items():
            if agent_id != sender_id:  # Don't send to self
                if hasattr(agent, "memory") and hasattr(agent.memory, "add"):
                    agent.memory.add("broadcast", f"Broadcast from {sender_name}: {content}", 
                                    {"sender_id": sender_id, "message_type": message_type})
        
        self.logger.info(f"Broadcast from {sender_name}: {content}")
    
    def send_message(self, sender_id: str, recipient_id: str, content: Any, 
                    message_type: str = "direct") -> bool:
        """Send a direct message from one agent to another."""
        if sender_id not in self.agents and sender_id != "system":
            self.logger.warning(f"Message attempted from unregistered sender: {sender_id}")
            return False
        
        if recipient_id not in self.agents:
            self.logger.warning(f"Message attempted to unregistered recipient: {recipient_id}")
            return False
        
        message = Message(sender_id, content, message_type)
        self.message_history.append(message)
        
        sender_name = "System" if sender_id == "system" else self.agents[sender_id].name
        recipient = self.agents[recipient_id]
        
        if hasattr(recipient, "memory") and hasattr(recipient.memory, "add"):
            recipient.memory.add("message", f"Message from {sender_name}: {content}", 
                               {"sender_id": sender_id, "message_type": message_type})
        
        self.logger.info(f"Message from {sender_name} to {recipient.name}: {content}")
        return True
    
    def register_event_listener(self, agent_id: str, event_type: str) -> bool:
        """Register an agent to listen for specific event types."""
        if agent_id not in self.agents:
            self.logger.warning(f"Attempted to register event listener for unregistered agent: {agent_id}")
            return False
        
        if event_type not in self.event_listeners:
            self.event_listeners[event_type] = set()
        
        self.event_listeners[event_type].add(agent_id)
        
        agent = self.agents[agent_id]
        self.logger.info(f"Agent {agent.name} registered to listen for {event_type} events")
        return True
    
    def unregister_event_listener(self, agent_id: str, event_type: str) -> bool:
        """Unregister an agent from listening for specific event types."""
        if event_type not in self.event_listeners:
            return False
        
        if agent_id not in self.event_listeners[event_type]:
            return False
        
        self.event_listeners[event_type].remove(agent_id)
        
        if agent_id in self.agents:
            agent = self.agents[agent_id]
            self.logger.info(f"Agent {agent.name} unregistered from {event_type} events")
        
        return True
    
    def trigger_event(self, event_type: str, data: Any) -> None:
        """Trigger an event and notify all registered listeners."""
        if event_type not in self.event_listeners:
            return
        
        for agent_id in self.event_listeners[event_type]:
            if agent_id in self.agents:
                agent = self.agents[agent_id]
                if hasattr(agent, "memory") and hasattr(agent.memory, "add"):
                    agent.memory.add("event", f"Event {event_type} triggered", 
                                    {"event_type": event_type, "data": data})
        
        self.logger.info(f"Event {event_type} triggered with data: {data}")
    
    def add_resource(self, resource_id: str, resource: Any) -> bool:
        """Add a resource to the environment."""
        if resource_id in self.resources:
            self.logger.warning(f"Resource with ID {resource_id} already exists")
            return False
        
        self.resources[resource_id] = resource
        self.logger.info(f"Added resource: {resource_id}")
        return True
    
    def get_resource(self, resource_id: str) -> Optional[Any]:
        """Get a resource from the environment."""
        return self.resources.get(resource_id)
    
    def remove_resource(self, resource_id: str) -> bool:
        """Remove a resource from the environment."""
        if resource_id not in self.resources:
            return False
        
        del self.resources[resource_id]
        self.logger.info(f"Removed resource: {resource_id}")
        return True
    
    def get_agent_by_name(self, name: str) -> Optional[Any]:
        """Get an agent by name."""
        if name not in self.agent_names:
            return None
        
        agent_id = self.agent_names[name]
        return self.agents.get(agent_id)
    
    def get_agent_by_id(self, agent_id: str) -> Optional[Any]:
        """Get an agent by ID."""
        return self.agents.get(agent_id)
    
    def get_all_agents(self) -> Dict[str, Any]:
        """Get all registered agents."""
        return self.agents
    
    def get_all_collectives(self) -> Dict[str, Any]:
        """Get all registered collectives."""
        return self.collectives
    
    def get_recent_messages(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent messages, optionally limited."""
        messages = [msg.to_dict() for msg in self.message_history]
        if limit:
            return messages[-limit:]
        return messages
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert environment to dictionary representation."""
        return {
            "agents": {agent_id: agent.name for agent_id, agent in self.agents.items()},
            "collectives": {coll_id: coll.name for coll_id, coll in self.collectives.items()},
            "resources": list(self.resources.keys()),
            "event_listeners": {event: list(agents) for event, agents in self.event_listeners.items()},
            "message_count": len(self.message_history),
            "created_at": self.created_at
        }

