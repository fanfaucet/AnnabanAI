import streamlit as st
import os
import json
import datetime
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from typing import Dict, List, Any, Optional
import sys
import random

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from annabanai.echo_loop import get_journal_entries, get_portfolio_items
from config import config
from token_economy.token_manager import TokenManager
from token_economy.marketplace import TokenMarketplace
from agents.base_agent import BaseAgent, Memory, Goal
from agents.task_agent import TaskAgent
from agents.social_agent import SocialAgent
from agents.collective import AgentCollective
from environment.environment import Environment
from environment.virtual_world import VirtualWorld

# Initialize token manager and marketplace
token_manager = TokenManager()
marketplace = TokenMarketplace(token_manager)

# Initialize environment
environment = Environment()

# Initialize virtual world
virtual_world = VirtualWorld("AnnabanOS World", (100.0, 100.0))

# Set page config
st.set_page_config(
    page_title="AnnabanOS Dashboard",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #4B8BBE;
        text-align: center;
        margin-bottom: 1rem;
    }
    .section-header {
        font-size: 1.8rem;
        color: #306998;
        margin-top: 1rem;
        margin-bottom: 0.5rem;
    }
    .card {
        border-radius: 5px;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .card-blue {
        background-color: #EFF8FF;
        border-left: 5px solid #4B8BBE;
    }
    .card-green {
        background-color: #EFFFEF;
        border-left: 5px solid #3CB371;
    }
    .card-yellow {
        background-color: #FFFAEF;
        border-left: 5px solid #FFD700;
    }
    .card-red {
        background-color: #FFEFEF;
        border-left: 5px solid #FF6B6B;
    }
    .card-purple {
        background-color: #F5EEFF;
        border-left: 5px solid #9370DB;
    }
    .card-title {
        font-weight: bold;
        margin-bottom: 0.5rem;
    }
    .card-content {
        font-size: 0.9rem;
    }
    .card-meta {
        font-size: 0.8rem;
        color: #666;
        margin-top: 0.5rem;
    }
    .token-value {
        font-size: 1.5rem;
        font-weight: bold;
        color: #306998;
    }
    .agent-name {
        font-weight: bold;
        color: #306998;
    }
    .timestamp {
        font-size: 0.8rem;
        color: #666;
    }
    .tag {
        background-color: #EFF8FF;
        border-radius: 10px;
        padding: 0.2rem 0.5rem;
        margin-right: 0.3rem;
        font-size: 0.8rem;
    }
</style>
""", unsafe_allow_html=True)

# Sidebar navigation
st.sidebar.markdown("# AnnabanOS Dashboard")
page = st.sidebar.selectbox(
    "Navigation",
    ["Home", "Journal", "Portfolio", "Agents", "Token Economy", "Virtual World", "Settings"]
)

# Create demo agents if they don't exist in session state
if "demo_agents_created" not in st.session_state:
    # Create task agents
    task_agent1 = TaskAgent("TaskMaster")
    task_agent1.earn_tokens(100, "Initial allocation")
    task_agent1.learn_skill("problem_solving", 0.8)
    task_agent1.learn_skill("data_analysis", 0.7)
    task_agent1.learn_skill("planning", 0.9)
    
    task_agent2 = TaskAgent("Analyzer")
    task_agent2.earn_tokens(80, "Initial allocation")
    task_agent2.learn_skill("research", 0.9)
    task_agent2.learn_skill("critical_thinking", 0.8)
    task_agent2.learn_skill("data_visualization", 0.7)
    
    # Create social agents
    social_agent1 = SocialAgent("Networker")
    social_agent1.earn_tokens(120, "Initial allocation")
    social_agent1.learn_skill("communication", 0.9)
    social_agent1.learn_skill("empathy", 0.8)
    social_agent1.learn_skill("negotiation", 0.7)
    
    social_agent2 = SocialAgent("Diplomat")
    social_agent2.earn_tokens(90, "Initial allocation")
    social_agent2.learn_skill("conflict_resolution", 0.9)
    social_agent2.learn_skill("persuasion", 0.8)
    social_agent2.learn_skill("leadership", 0.7)
    
    # Register agents with environment
    environment.register_agent(task_agent1)
    environment.register_agent(task_agent2)
    environment.register_agent(social_agent1)
    environment.register_agent(social_agent2)
    
    # Create a collective
    collective = AgentCollective("Dream Team")
    collective.add_agent(task_agent1, "coordinator")
    collective.add_agent(task_agent2, "analyst")
    collective.add_agent(social_agent1, "creator")
    collective.add_agent(social_agent2, "evaluator")
    
    # Register collective with environment
    environment.register_collective(collective)
    
    # Add agents to virtual world
    virtual_world.add_agent(task_agent1.id, (20.0, 30.0), {"icon": "🧠"})
    virtual_world.add_agent(task_agent2.id, (40.0, 20.0), {"icon": "📊"})
    virtual_world.add_agent(social_agent1.id, (60.0, 40.0), {"icon": "🗣️"})
    virtual_world.add_agent(social_agent2.id, (80.0, 70.0), {"icon": "🤝"})
    
    # Add locations to virtual world
    from environment.virtual_world import VirtualLocation
    virtual_world.add_location(VirtualLocation("Task Hub", (30.0, 30.0), 15.0, {"type": "work"}))
    virtual_world.add_location(VirtualLocation("Social Center", (70.0, 50.0), 20.0, {"type": "social"}))
    virtual_world.add_location(VirtualLocation("Learning Zone", (50.0, 80.0), 10.0, {"type": "education"}))
    
    # Add objects to virtual world
    from environment.virtual_world import VirtualObject
    virtual_world.add_object(VirtualObject("Knowledge Base", (25.0, 25.0), {"type": "resource", "value": 10}))
    virtual_world.add_object(VirtualObject("Communication Hub", (75.0, 45.0), {"type": "tool", "value": 15}))
    virtual_world.add_object(VirtualObject("Token Vault", (50.0, 50.0), {"type": "economic", "value": 20}))
    
    # Create marketplace listings
    marketplace.create_listing(
        task_agent1.id,
        "Problem-Solving Service",
        "Expert problem-solving assistance for complex challenges",
        25.0,
        "task_service",
        {"skill_level": 0.8, "duration": "1 day"}
    )
    
    marketplace.create_listing(
        task_agent2.id,
        "Data Analysis Report",
        "Comprehensive data analysis with visualizations and insights",
        40.0,
        "information",
        {"skill_level": 0.7, "format": "PDF"}
    )
    
    marketplace.create_listing(
        social_agent1.id,
        "Network Introduction",
        "Introduction to key agents in my network",
        15.0,
        "social_service",
        {"connections": 5, "quality": "high"}
    )
    
    marketplace.create_listing(
        social_agent2.id,
        "Conflict Resolution",
        "Professional mediation and conflict resolution services",
        35.0,
        "social_service",
        {"skill_level": 0.9, "success_rate": 0.95}
    )
    
    # Mark as created
    st.session_state.demo_agents_created = True
    st.session_state.task_agent1 = task_agent1
    st.session_state.task_agent2 = task_agent2
    st.session_state.social_agent1 = social_agent1
    st.session_state.social_agent2 = social_agent2
    st.session_state.collective = collective

# Home page
if page == "Home":
    st.markdown("<h1 class='main-header'>AnnabanOS Dashboard</h1>", unsafe_allow_html=True)
    
    # System overview
    st.markdown("<h2 class='section-header'>System Overview</h2>", unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class='card card-blue'>
            <div class='card-title'>Agents</div>
            <div class='token-value'>4</div>
            <div class='card-meta'>2 Task, 2 Social</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class='card card-green'>
            <div class='card-title'>Token Economy</div>
            <div class='token-value'>390</div>
            <div class='card-meta'>Total Tokens in Circulation</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        journal_entries = get_journal_entries()
        st.markdown(f"""
        <div class='card card-yellow'>
            <div class='card-title'>Journal Entries</div>
            <div class='token-value'>{len(journal_entries)}</div>
            <div class='card-meta'>Reflections & Thoughts</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        portfolio_items = get_portfolio_items()
        st.markdown(f"""
        <div class='card card-purple'>
            <div class='card-title'>Portfolio Items</div>
            <div class='token-value'>{len(portfolio_items)}</div>
            <div class='card-meta'>Achievements & Skills</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Recent activity
    st.markdown("<h2 class='section-header'>Recent Activity</h2>", unsafe_allow_html=True)
    
    # Combine journal entries and portfolio items for activity feed
    journal_entries = get_journal_entries(limit=5)
    portfolio_items = get_portfolio_items(limit=5)
    
    # Sort by timestamp (newest first)
    all_items = journal_entries + portfolio_items
    all_items.sort(key=lambda x: x["timestamp"], reverse=True)
    
    for item in all_items[:5]:
        if "category" in item:  # Journal entry
            card_class = "card-blue"
            item_type = "Reflection"
            meta_info = f"Category: {item['category']}"
        else:  # Portfolio item
            card_class = "card-green"
            item_type = "Portfolio"
            meta_info = f"Type: {item['item_type']}"
        
        st.markdown(f"""
        <div class='card {card_class}'>
            <div class='card-title'>{item_type} - {item['timestamp'][:16].replace('T', ' ')}</div>
            <div class='card-content'>{item['content']}</div>
            <div class='card-meta'>{meta_info}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # System stats
    st.markdown("<h2 class='section-header'>System Statistics</h2>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Token distribution pie chart
        token_data = {
            "Agent": ["TaskMaster", "Analyzer", "Networker", "Diplomat"],
            "Tokens": [100, 80, 120, 90]
        }
        df_tokens = pd.DataFrame(token_data)
        fig_tokens = px.pie(
            df_tokens, 
            values="Tokens", 
            names="Agent", 
            title="Token Distribution",
            color_discrete_sequence=px.colors.sequential.Blues
        )
        st.plotly_chart(fig_tokens, use_container_width=True)
    
    with col2:
        # Agent skills radar chart
        categories = ['Problem Solving', 'Data Analysis', 'Communication', 
                     'Leadership', 'Research', 'Negotiation']
        
        fig_skills = go.Figure()
        
        fig_skills.add_trace(go.Scatterpolar(
            r=[0.8, 0.7, 0.5, 0.6, 0.4, 0.3],
            theta=categories,
            fill='toself',
            name='TaskMaster'
        ))
        
        fig_skills.add_trace(go.Scatterpolar(
            r=[0.6, 0.5, 0.4, 0.3, 0.9, 0.5],
            theta=categories,
            fill='toself',
            name='Analyzer'
        ))
        
        fig_skills.add_trace(go.Scatterpolar(
            r=[0.5, 0.4, 0.9, 0.5, 0.6, 0.7],
            theta=categories,
            fill='toself',
            name='Networker'
        ))
        
        fig_skills.add_trace(go.Scatterpolar(
            r=[0.6, 0.3, 0.7, 0.7, 0.5, 0.8],
            theta=categories,
            fill='toself',
            name='Diplomat'
        ))
        
        fig_skills.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 1]
                )
            ),
            title="Agent Skills"
        )
        
        st.plotly_chart(fig_skills, use_container_width=True)

# Journal page
elif page == "Journal":
    st.markdown("<h1 class='main-header'>Journal Entries</h1>", unsafe_allow_html=True)
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        category_filter = st.selectbox(
            "Filter by Category",
            ["All Categories", "general", "task_completion", "learning", 
             "social_interaction", "problem_solving", "goal_setting"]
        )
    
    with col2:
        sort_order = st.selectbox(
            "Sort Order",
            ["Newest First", "Oldest First"]
        )
    
    with col3:
        limit = st.slider("Number of Entries", 5, 50, 20)
    
    # Get journal entries
    if category_filter == "All Categories":
        journal_entries = get_journal_entries(limit=limit)
    else:
        journal_entries = get_journal_entries(category=category_filter, limit=limit)
    
    # Sort entries
    if sort_order == "Oldest First":
        journal_entries.sort(key=lambda x: x["timestamp"])
    else:
        journal_entries.sort(key=lambda x: x["timestamp"], reverse=True)
    
    # Display entries
    for entry in journal_entries:
        timestamp = entry["timestamp"][:16].replace('T', ' ')
        category = entry["category"]
        content = entry["content"]
        tags = entry.get("tags", [])
        
        tags_html = ""
        for tag in tags:
            tags_html += f"<span class='tag'>{tag}</span>"
        
        st.markdown(f"""
        <div class='card card-blue'>
            <div class='card-title'>
                <span class='timestamp'>{timestamp}</span> - 
                <span class='category'>{category.capitalize()}</span>
            </div>
            <div class='card-content'>{content}</div>
            <div class='card-meta'>{tags_html}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Add new entry form
    st.markdown("<h2 class='section-header'>Add New Journal Entry</h2>", unsafe_allow_html=True)
    
    new_category = st.selectbox(
        "Category",
        ["general", "task_completion", "learning", "social_interaction", "problem_solving", "goal_setting"]
    )
    
    new_content = st.text_area("Content", height=100)
    
    new_tags = st.text_input("Tags (comma separated)")
    
    if st.button("Add Entry"):
        from annabanai.echo_loop import reflect
        
        # Process tags
        tags_list = [tag.strip() for tag in new_tags.split(",") if tag.strip()]
        metadata = {"tags": tags_list} if tags_list else None
        
        # Add entry
        reflect(new_content, new_category, metadata)
        st.success("Journal entry added successfully!")
        st.experimental_rerun()

# Portfolio page
elif page == "Portfolio":
    st.markdown("<h1 class='main-header'>Portfolio Items</h1>", unsafe_allow_html=True)
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        type_filter = st.selectbox(
            "Filter by Type",
            ["All Types", "achievement", "skill_development", "insight", "project", "goal"]
        )
    
    with col2:
        sort_order = st.selectbox(
            "Sort Order",
            ["Newest First", "Oldest First"]
        )
    
    with col3:
        limit = st.slider("Number of Items", 5, 50, 20)
    
    # Get portfolio items
    if type_filter == "All Types":
        portfolio_items = get_portfolio_items(limit=limit)
    else:
        portfolio_items = get_portfolio_items(item_type=type_filter, limit=limit)
    
    # Sort items
    if sort_order == "Oldest First":
        portfolio_items.sort(key=lambda x: x["timestamp"])
    else:
        portfolio_items.sort(key=lambda x: x["timestamp"], reverse=True)
    
    # Display items
    for item in portfolio_items:
        timestamp = item["timestamp"][:16].replace('T', ' ')
        item_type = item["item_type"]
        content = item["content"]
        tags = item.get("tags", [])
        
        tags_html = ""
        for tag in tags:
            tags_html += f"<span class='tag'>{tag}</span>"
        
        st.markdown(f"""
        <div class='card card-green'>
            <div class='card-title'>
                <span class='timestamp'>{timestamp}</span> - 
                <span class='category'>{item_type.capitalize()}</span>
            </div>
            <div class='card-content'>{content}</div>
            <div class='card-meta'>{tags_html}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Add new item form
    st.markdown("<h2 class='section-header'>Add New Portfolio Item</h2>", unsafe_allow_html=True)
    
    new_type = st.selectbox(
        "Type",
        ["achievement", "skill_development", "insight", "project", "goal"]
    )
    
    new_content = st.text_area("Content", height=100)
    
    new_tags = st.text_input("Tags (comma separated)")
    
    if st.button("Add Item"):
        from annabanai.echo_loop import update_portfolio
        
        # Process tags
        tags_list = [tag.strip() for tag in new_tags.split(",") if tag.strip()]
        metadata = {"tags": tags_list} if tags_list else None
        
        # Add item
        update_portfolio(new_content, new_type, metadata)
        st.success("Portfolio item added successfully!")
        st.experimental_rerun()

# Agents page
elif page == "Agents":
    st.markdown("<h1 class='main-header'>Agent Management</h1>", unsafe_allow_html=True)
    
    # Agent tabs
    agent_tab = st.selectbox(
        "View",
        ["Individual Agents", "Agent Collective", "Agent Interactions"]
    )
    
    if agent_tab == "Individual Agents":
        # Display individual agents
        st.markdown("<h2 class='section-header'>Individual Agents</h2>", unsafe_allow_html=True)
        
        # Get agents from session state
        agents = [
            st.session_state.task_agent1,
            st.session_state.task_agent2,
            st.session_state.social_agent1,
            st.session_state.social_agent2
        ]
        
        # Display agent cards
        for i, agent in enumerate(agents):
            if i % 2 == 0:
                col1, col2 = st.columns(2)
            
            with col1 if i % 2 == 0 else col2:
                card_class = "card-blue" if isinstance(agent, TaskAgent) else "card-purple"
                agent_type = "Task Agent" if isinstance(agent, TaskAgent) else "Social Agent"
                
                # Get agent skills
                skills_html = ""
                if hasattr(agent, "skills"):
                    for skill, level in agent.skills.items():
                        skills_html += f"<div>{skill}: {level:.1f}</div>"
                
                # Get agent goals
                goals_html = ""
                if hasattr(agent, "goals"):
                    for goal in agent.goals:
                        status = "✅" if goal.completed else "⏳"
                        goals_html += f"<div>{status} {goal.description}</div>"
                
                st.markdown(f"""
                <div class='card {card_class}'>
                    <div class='card-title'>{agent.name} - {agent_type}</div>
                    <div class='card-content'>
                        <div><strong>ID:</strong> {agent.id[:8]}...</div>
                        <div><strong>Tokens:</strong> {agent.tokens:.1f}</div>
                        <div><strong>Skills:</strong></div>
                        {skills_html}
                        <div><strong>Goals:</strong></div>
                        {goals_html or "<div>No active goals</div>"}
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        # Add new agent form
        st.markdown("<h2 class='section-header'>Add New Agent</h2>", unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            new_agent_name = st.text_input("Agent Name")
            new_agent_type = st.selectbox("Agent Type", ["Task Agent", "Social Agent"])
        
        with col2:
            new_agent_tokens = st.number_input("Initial Tokens", min_value=0.0, value=50.0)
            new_agent_skill = st.text_input("Initial Skill (name:level, e.g. coding:0.8)")
        
        if st.button("Create Agent"):
            # Parse skill
            skill_name = ""
            skill_level = 0.5
            if ":" in new_agent_skill:
                parts = new_agent_skill.split(":")
                skill_name = parts[0].strip()
                try:
                    skill_level = float(parts[1].strip())
                except:
                    pass
            
            # Create agent
            if new_agent_type == "Task Agent":
                new_agent = TaskAgent(new_agent_name)
            else:
                new_agent = SocialAgent(new_agent_name)
            
            # Add tokens and skill
            new_agent.earn_tokens(new_agent_tokens, "Initial allocation")
            if skill_name:
                new_agent.learn_skill(skill_name, skill_level)
            
            # Register with environment
            environment.register_agent(new_agent)
            
            # Add to virtual world
            import random
            x = random.uniform(10.0, 90.0)
            y = random.uniform(10.0, 90.0)
            virtual_world.add_agent(new_agent.id, (x, y), {"icon": "🤖"})
            
            st.success(f"Agent {new_agent_name} created successfully!")
    
    elif agent_tab == "Agent Collective":
        # Display agent collective
        st.markdown("<h2 class='section-header'>Agent Collective</h2>", unsafe_allow_html=True)
        
        collective = st.session_state.collective
        
        # Display collective info
        st.markdown(f"""
        <div class='card card-yellow'>
            <div class='card-title'>{collective.name}</div>
            <div class='card-content'>
                <div><strong>ID:</strong> {collective.id[:8]}...</div>
                <div><strong>Agents:</strong> {len(collective.agents)}</div>
                <div><strong>Created:</strong> {collective.created_at[:16].replace('T', ' ')}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Display agents in collective
        st.markdown("<h3>Collective Members</h3>", unsafe_allow_html=True)
        
        for agent_id, role in collective.agent_roles.items():
            agent = collective.agents.get(agent_id)
            if not agent:
                continue
            
            st.markdown(f"""
            <div class='card card-blue'>
                <div class='card-title'>{agent.name} - {role.capitalize()}</div>
                <div class='card-content'>
                    <div><strong>ID:</strong> {agent.id[:8]}...</div>
                    <div><strong>Tokens:</strong> {agent.tokens:.1f}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        # Create task form
        st.markdown("<h3>Create Collective Task</h3>", unsafe_allow_html=True)
        
        task_description = st.text_area("Task Description")
        
        col1, col2 = st.columns(2)
        
        with col1:
            task_difficulty = st.slider("Difficulty", 0.1, 1.0, 0.5, 0.1)
        
        with col2:
            task_reward = st.number_input("Reward", min_value=10.0, value=50.0)
        
        required_roles = st.multiselect(
            "Required Roles",
            ["coordinator", "analyst", "creator", "implementer", "evaluator"],
            ["coordinator", "analyst"]
        )
        
        if st.button("Create Task"):
            # Create task
            task = collective.create_task(
                task_description,
                task_difficulty,
                task_reward,
                required_roles
            )
            
            # Assign roles
            collective.assign_task_roles(task.id)
            
            # Execute task
            result = collective.execute_task(task.id)
            
            if result["success"]:
                st.success(f"Task completed successfully! Quality: {result['quality']:.2f}")
            else:
                st.error(f"Task failed: {result['reason']}")
    
    else:  # Agent Interactions
        # Display agent interactions
        st.markdown("<h2 class='section-header'>Agent Interactions</h2>", unsafe_allow_html=True)
        
        # Get agents from session state
        agents = [
            st.session_state.task_agent1,
            st.session_state.task_agent2,
            st.session_state.social_agent1,
            st.session_state.social_agent2
        ]
        
        # Interaction form
        st.markdown("<h3>Create Interaction</h3>", unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            sender_idx = st.selectbox("Sender", range(len(agents)), format_func=lambda i: agents[i].name)
        
        with col2:
            recipient_idx = st.selectbox("Recipient", range(len(agents)), format_func=lambda i: agents[i].name)
        
        message_type = st.selectbox("Message Type", ["general", "task", "social", "economic"])
        message_content = st.text_area("Message Content")
        
        if st.button("Send Message"):
            sender = agents[sender_idx]
            recipient = agents[recipient_idx]
            
            # Send message through environment
            success = environment.send_message(
                sender.id,
                recipient.id,
                message_content,
                message_type
            )
            
            if success:
                st.success(f"Message sent from {sender.name} to {recipient.name}")
            else:
                st.error("Failed to send message")
        
        # Display recent messages
        st.markdown("<h3>Recent Messages</h3>", unsafe_allow_html=True)
        
        messages = environment.get_recent_messages(10)
        
        for message in messages:
            sender_id = message["sender_id"]
            sender_name = "System"
            
            if sender_id != "system":
                sender_agent = environment.get_agent_by_id(sender_id)
                if sender_agent:
                    sender_name = sender_agent.name
            
            recipient_id = message["recipient_id"]
            recipient_name = "All"
            
            if recipient_id:
                recipient_agent = environment.get_agent_by_id(recipient_id)
                if recipient_agent:
                    recipient_name = recipient_agent.name
            
            timestamp = message["timestamp"][:16].replace('T', ' ')
            content = message["content"]
            message_type = message["message_type"]
            
            st.markdown(f"""
            <div class='card card-blue'>
                <div class='card-title'>
                    <span class='timestamp'>{timestamp}</span> - 
                    <span class='agent-name'>{sender_name}</span> to 
                    <span class='agent-name'>{recipient_name}</span>
                </div>
                <div class='card-content'>{content}</div>
                <div class='card-meta'>Type: {message_type}</div>
            </div>
            """, unsafe_allow_html=True)

# Token Economy page
elif page == "Token Economy":
    st.markdown("<h1 class='main-header'>Token Economy</h1>", unsafe_allow_html=True)
    
    # Token economy tabs
    token_tab = st.selectbox(
        "View",
        ["Token Overview", "Marketplace", "Transactions"]
    )
    
    if token_tab == "Token Overview":
        # Display token overview
        st.markdown("<h2 class='section-header'>Token Overview</h2>", unsafe_allow_html=True)
        
        # Token stats
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown(f"""
            <div class='card card-green'>
                <div class='card-title'>Total Supply</div>
                <div class='token-value'>{token_manager.get_total_supply():.1f}</div>
                <div class='card-meta'>{token_manager.currency_name}</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class='card card-blue'>
                <div class='card-title'>Transaction Count</div>
                <div class='token-value'>{len(token_manager.transactions)}</div>
                <div class='card-meta'>Total Transactions</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div class='card card-yellow'>
                <div class='card-title'>Interest Rate</div>
                <div class='token-value'>{token_manager.interest_rate * 100:.1f}%</div>
                <div class='card-meta'>Per Cycle</div>
            </div>
            """, unsafe_allow_html=True)
        
        # Token distribution
        st.markdown("<h3>Token Distribution</h3>", unsafe_allow_html=True)
        
        # Get agents from session state
        agents = [
            st.session_state.task_agent1,
            st.session_state.task_agent2,
            st.session_state.social_agent1,
            st.session_state.social_agent2
        ]
        
        # Create token distribution data
        token_data = {
            "Agent": [agent.name for agent in agents],
            "Tokens": [agent.tokens for agent in agents]
        }
        df_tokens = pd.DataFrame(token_data)
        
        # Display bar chart
        fig_tokens = px.bar(
            df_tokens,
            x="Agent",
            y="Tokens",
            title="Token Distribution",
            color="Agent",
            color_discrete_sequence=px.colors.sequential.Blues
        )
        st.plotly_chart(fig_tokens, use_container_width=True)
        
        # Token actions
        st.markdown("<h3>Token Actions</h3>", unsafe_allow_html=True)
        
        action = st.selectbox(
            "Action",
            ["Create Tokens", "Transfer Tokens", "Stake Tokens", "Apply Interest"]
        )
        
        if action == "Create Tokens":
            col1, col2 = st.columns(2)
            
            with col1:
                recipient_idx = st.selectbox("Recipient", range(len(agents)), format_func=lambda i: agents[i].name)
            
            with col2:
                amount = st.number_input("Amount", min_value=1.0, value=10.0)
            
            reason = st.text_input("Reason")
            
            if st.button("Create Tokens"):
                recipient = agents[recipient_idx]
                
                # Create tokens
                success = token_manager.create_tokens(recipient.id, amount, reason)
                
                if success:
                    # Update agent tokens
                    recipient.tokens += amount
                    st.success(f"Created {amount} {token_manager.currency_name} for {recipient.name}")
                else:
                    st.error("Failed to create tokens")
        
        elif action == "Transfer Tokens":
            col1, col2 = st.columns(2)
            
            with col1:
                sender_idx = st.selectbox("Sender", range(len(agents)), format_func=lambda i: agents[i].name)
            
            with col2:
                recipient_idx = st.selectbox("Recipient", range(len(agents)), format_func=lambda i: agents[i].name)
            
            amount = st.number_input("Amount", min_value=1.0, value=5.0)
            description = st.text_input("Description")
            
            if st.button("Transfer Tokens"):
                sender = agents[sender_idx]
                recipient = agents[recipient_idx]
                
                # Transfer tokens
                success = token_manager.transfer_tokens(sender.id, recipient.id, amount, description)
                
                if success:
                    # Update agent tokens (already done in token_manager)
                    st.success(f"Transferred {amount} {token_manager.currency_name} from {sender.name} to {recipient.name}")
                else:
                    st.error("Failed to transfer tokens")
        
        elif action == "Stake Tokens":
            col1, col2 = st.columns(2)
            
            with col1:
                agent_idx = st.selectbox("Agent", range(len(agents)), format_func=lambda i: agents[i].name)
            
            with col2:
                amount = st.number_input("Amount", min_value=1.0, value=10.0)
            
            if st.button("Stake Tokens"):
                agent = agents[agent_idx]
                
                # Stake tokens
                success = token_manager.stake_tokens(agent.id, amount)
                
                if success:
                    # Update agent tokens (already done in token_manager)
                    st.success(f"{agent.name} staked {amount} {token_manager.currency_name}")
                else:
                    st.error("Failed to stake tokens")
        
        else:  # Apply Interest
            if st.button("Apply Interest"):
                # Apply interest
                interest_payments = token_manager.apply_interest()
                
                if interest_payments:
                    # Update agent tokens
                    for agent_id, interest in interest_payments.items():
                        for agent in agents:
                            if agent.id == agent_id:
                                agent.tokens += interest
                    
                    st.success(f"Applied interest to {len(interest_payments)} agents")
                else:
                    st.info("No staked tokens to apply interest to")
    
    elif token_tab == "Marketplace":
        # Display marketplace
        st.markdown("<h2 class='section-header'>Token Marketplace</h2>", unsafe_allow_html=True)
        
        # Marketplace stats
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown(f"""
            <div class='card card-green'>
                <div class='card-title'>Active Listings</div>
                <div class='token-value'>{len(marketplace.get_active_listings())}</div>
                <div class='card-meta'>Available for Purchase</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class='card card-blue'>
                <div class='card-title'>Transaction Count</div>
                <div class='token-value'>{len(marketplace.transactions)}</div>
                <div class='card-meta'>Completed Purchases</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div class='card card-yellow'>
                <div class='card-title'>Commission Rate</div>
                <div class='token-value'>{marketplace.commission_rate * 100:.1f}%</div>
                <div class='card-meta'>Per Transaction</div>
            </div>
            """, unsafe_allow_html=True)
        
        # Marketplace listings
        st.markdown("<h3>Active Listings</h3>", unsafe_allow_html=True)
        
        # Filter by category
        category_filter = st.selectbox(
            "Filter by Category",
            ["All Categories"] + list(marketplace.categories)
        )
        
        # Get listings
        if category_filter == "All Categories":
            listings = marketplace.get_active_listings()
        else:
            listings = marketplace.get_active_listings(category=category_filter)
        
        # Display listings
        for listing in listings:
            seller_id = listing["seller_id"]
            seller_agent = environment.get_agent_by_id(seller_id)
            seller_name = seller_agent.name if seller_agent else "Unknown"
            
            st.markdown(f"""
            <div class='card card-green'>
                <div class='card-title'>{listing["title"]} - {listing["price"]} {token_manager.currency_name}</div>
                <div class='card-content'>{listing["description"]}</div>
                <div class='card-meta'>
                    Seller: {seller_name} | Category: {listing["category"]}
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        # Create listing form
        st.markdown("<h3>Create Listing</h3>", unsafe_allow_html=True)
        
        # Get agents from session state
        agents = [
            st.session_state.task_agent1,
            st.session_state.task_agent2,
            st.session_state.social_agent1,
            st.session_state.social_agent2
        ]
        
        col1, col2 = st.columns(2)
        
        with col1:
            seller_idx = st.selectbox("Seller", range(len(agents)), format_func=lambda i: agents[i].name)
            title = st.text_input("Title")
        
        with col2:
            category = st.selectbox("Category", list(marketplace.categories))
            price = st.number_input("Price", min_value=1.0, value=25.0)
        
        description = st.text_area("Description")
        
        if st.button("Create Listing"):
            seller = agents[seller_idx]
            
            # Create listing
            listing_id = marketplace.create_listing(
                seller.id,
                title,
                description,
                price,
                category
            )
            
            if listing_id:
                st.success(f"Listing created: {title}")
            else:
                st.error("Failed to create listing")
    
    else:  # Transactions
        # Display transactions
        st.markdown("<h2 class='section-header'>Token Transactions</h2>", unsafe_allow_html=True)
        
        # Get transactions
        transactions = token_manager.get_transaction_history(limit=20)
        
        # Display transactions
        for transaction in transactions:
            sender_id = transaction["sender_id"]
            sender_name = "System"
            
            if sender_id:
                sender_agent = environment.get_agent_by_id(sender_id)
                if sender_agent:
                    sender_name = sender_agent.name
            
            recipient_id = transaction["recipient_id"]
            recipient_agent = environment.get_agent_by_id(recipient_id)
            recipient_name = recipient_agent.name if recipient_agent else "Unknown"
            
            timestamp = transaction["timestamp"][:16].replace('T', ' ')
            amount = transaction["amount"]
            transaction_type = transaction["transaction_type"]
            description = transaction["description"]
            
            st.markdown(f"""
            <div class='card card-blue'>
                <div class='card-title'>
                    <span class='timestamp'>{timestamp}</span> - 
                    {amount} {token_manager.currency_name}
                </div>
                <div class='card-content'>
                    <strong>From:</strong> {sender_name} <strong>To:</strong> {recipient_name}
                    <div>{description}</div>
                </div>
                <div class='card-meta'>Type: {transaction_type}</div>
            </div>
            """, unsafe_allow_html=True)

# Virtual World page
elif page == "Virtual World":
    st.markdown("<h1 class='main-header'>Virtual World</h1>", unsafe_allow_html=True)
    
    # World info
    st.markdown(f"""
    <div class='card card-blue'>
        <div class='card-title'>{virtual_world.name}</div>
        <div class='card-content'>
            <div><strong>Size:</strong> {virtual_world.size[0]} x {virtual_world.size[1]}</div>
            <div><strong>Agents:</strong> {len(virtual_world.virtual_agents)}</div>
            <div><strong>Locations:</strong> {len(virtual_world.locations)}</div>
            <div><strong>Objects:</strong> {len(virtual_world.objects)}</div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # World visualization
    st.markdown("<h2 class='section-header'>World Map</h2>", unsafe_allow_html=True)
    
    # Create dataframes for plotting
    # Agents
    agent_data = []
    for agent_id, virtual_agent in virtual_world.virtual_agents.items():
        agent = environment.get_agent_by_id(agent_id)
        name = agent.name if agent else "Unknown"
        icon = virtual_agent.get_property("icon", "🤖")
        agent_data.append({
            "x": virtual_agent.position[0],
            "y": virtual_agent.position[1],
            "name": name,
            "type": "Agent",
            "icon": icon
        })
    df_agents = pd.DataFrame(agent_data)
    
    # Locations
    location_data = []
    for location_id, location in virtual_world.locations.items():
        location_data.append({
            "x": location.position[0],
            "y": location.position[1],
            "name": location.name,
            "type": "Location",
            "radius": location.radius
        })
    df_locations = pd.DataFrame(location_data)
    
    # Objects
    object_data = []
    for object_id, obj in virtual_world.objects.items():
        object_data.append({
            "x": obj.position[0],
            "y": obj.position[1],
            "name": obj.name,
            "type": "Object"
        })
    df_objects = pd.DataFrame(object_data)
    
    # Create plot
    fig = go.Figure()
    
    # Add locations as circles
    for _, row in df_locations.iterrows():
        fig.add_shape(
            type="circle",
            xref="x", yref="y",
            x0=row["x"] - row["radius"],
            y0=row["y"] - row["radius"],
            x1=row["x"] + row["radius"],
            y1=row["y"] + row["radius"],
            fillcolor="rgba(140, 180, 240, 0.2)",
            line_color="rgba(140, 180, 240, 0.5)"
        )
    
    # Add locations as points
    if not df_locations.empty:
        fig.add_trace(go.Scatter(
            x=df_locations["x"],
            y=df_locations["y"],
            mode="markers+text",
            marker=dict(size=15, color="blue", symbol="square"),
            text=df_locations["name"],
            textposition="top center",
            name="Locations"
        ))
    
    # Add objects
    if not df_objects.empty:
        fig.add_trace(go.Scatter(
            x=df_objects["x"],
            y=df_objects["y"],
            mode="markers+text",
            marker=dict(size=10, color="green", symbol="diamond"),
            text=df_objects["name"],
            textposition="top center",
            name="Objects"
        ))
    
    # Add agents
    if not df_agents.empty:
        # Create text with icons
        agent_text = [f"{row['icon']} {row['name']}" for _, row in df_agents.iterrows()]
        
        fig.add_trace(go.Scatter(
            x=df_agents["x"],
            y=df_agents["y"],
            mode="markers+text",
            marker=dict(size=12, color="red"),
            text=agent_text,
            textposition="top center",
            name="Agents"
        ))
    
    # Update layout
    fig.update_layout(
        title="Virtual World Map",
        xaxis=dict(range=[0, virtual_world.size[0]]),
        yaxis=dict(range=[0, virtual_world.size[1]]),
        height=600
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Agent movement
    st.markdown("<h2 class='section-header'>Agent Movement</h2>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Get agents from session state
        agents = [
            st.session_state.task_agent1,
            st.session_state.task_agent2,
            st.session_state.social_agent1,
            st.session_state.social_agent2
        ]
        
        agent_idx = st.selectbox("Agent", range(len(agents)), format_func=lambda i: agents[i].name)
    
    with col2:
        movement_type = st.selectbox("Movement Type", ["Specific Position", "Random Position", "Towards Location"])
    
    if movement_type == "Specific Position":
        col1, col2 = st.columns(2)
        
        with col1:
            x_pos = st.slider("X Position", 0.0, virtual_world.size[0], 50.0, 1.0)
        
        with col2:
            y_pos = st.slider("Y Position", 0.0, virtual_world.size[1], 50.0, 1.0)
        
        if st.button("Move Agent"):
            agent = agents[agent_idx]
            
            # Move agent
            success = virtual_world.move_agent(agent.id, (x_pos, y_pos))
            
            if success:
                st.success(f"Moved {agent.name} to position ({x_pos}, {y_pos})")
            else:
                st.error(f"Failed to move {agent.name}")
    
    elif movement_type == "Random Position":
        if st.button("Move to Random Position"):
            agent = agents[agent_idx]
            
            # Generate random position
            random_pos = virtual_world.get_random_position()
            
            # Move agent
            success = virtual_world.move_agent(agent.id, random_pos)
            
            if success:
                st.success(f"Moved {agent.name} to random position ({random_pos[0]:.1f}, {random_pos[1]:.1f})")
            else:
                st.error(f"Failed to move {agent.name}")
    
    else:  # Towards Location
        # Get locations
        location_names = [location.name for location in virtual_world.locations.values()]
        
        location_name = st.selectbox("Target Location", location_names)
        
        if st.button("Move Towards Location"):
            agent = agents[agent_idx]
            
            # Find location
            target_location = None
            for location in virtual_world.locations.values():
                if location.name == location_name:
                    target_location = location
                    break
            
            if target_location:
                # Move agent
                success = virtual_world.move_agent(agent.id, target_location.position)
                
                if success:
                    st.success(f"Moved {agent.name} to {location_name}")
                else:
                    st.error(f"Failed to move {agent.name}")
            else:
                st.error(f"Location {location_name} not found")

# Settings page
else:  # Settings
    st.markdown("<h1 class='main-header'>Settings</h1>", unsafe_allow_html=True)
    
    # System settings
    st.markdown("<h2 class='section-header'>System Settings</h2>", unsafe_allow_html=True)
    
    # Display current configuration
    st.json(config.get_all())
    
    # Update configuration form
    st.markdown("<h3>Update Configuration</h3>", unsafe_allow_html=True)
    
    setting_path = st.text_input("Setting Path (e.g., token_economy.interest_rate)")
    setting_value = st.text_input("Setting Value")
    
    if st.button("Update Setting"):
        try:
            # Parse value
            if setting_value.lower() == "true":
                value = True
            elif setting_value.lower() == "false":
                value = False
            elif setting_value.isdigit():
                value = int(setting_value)
            else:
                try:
                    value = float(setting_value)
                except:
                    value = setting_value
            
            # Update configuration
            config.set(setting_path, value)
            st.success(f"Updated {setting_path} to {value}")
        except Exception as e:
            st.error(f"Failed to update setting: {e}")
    
    # Reset configuration
    if st.button("Reset to Defaults"):
        config.reset_to_defaults()
        st.success("Reset configuration to defaults")
        st.experimental_rerun()

if __name__ == "__main__":
    pass

