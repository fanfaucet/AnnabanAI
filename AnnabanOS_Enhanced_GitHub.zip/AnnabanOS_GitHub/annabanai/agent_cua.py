import logging
import datetime
from typing import Any, Dict, List, Optional, Tuple
import uuid
import random

from agents.base_agent import BaseAgent
from annabanai.echo_loop import reflect, update_portfolio
from config import config

class ConversationHistory:
    """Class for managing conversation history."""
    
    def __init__(self, capacity: int = 100):
        """Initialize conversation history with optional capacity limit."""
        self.capacity = capacity
        self.messages = []
    
    def add(self, role: str, content: str, metadata: Dict[str, Any] = None) -> None:
        """Add a message to the history."""
        timestamp = datetime.datetime.now().isoformat()
        message = {
            "id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "timestamp": timestamp,
            "metadata": metadata or {}
        }
        
        self.messages.append(message)
        
        # If over capacity, remove oldest messages
        if self.capacity and len(self.messages) > self.capacity:
            self.messages = self.messages[-self.capacity:]
    
    def get_recent(self, count: int = 10) -> List[Dict[str, Any]]:
        """Get the most recent messages."""
        return self.messages[-count:] if count < len(self.messages) else self.messages
    
    def get_all(self) -> List[Dict[str, Any]]:
        """Get all messages in the history."""
        return self.messages
    
    def clear(self) -> None:
        """Clear the conversation history."""
        self.messages = []


class ConversationalUserAgent(BaseAgent):
    """Enhanced Conversational User Agent with improved capabilities."""
    
    def __init__(self, name: str):
        """Initialize the conversational agent."""
        super().__init__(name)
        self.conversation_history = ConversationHistory()
        self.personality_traits = {
            "friendliness": random.uniform(0.5, 0.9),
            "formality": random.uniform(0.3, 0.7),
            "verbosity": random.uniform(0.4, 0.8),
            "curiosity": random.uniform(0.5, 0.9),
            "helpfulness": random.uniform(0.7, 1.0)
        }
        self.conversation_topics = {}  # topic -> familiarity (0.0 to 1.0)
        self.response_templates = {}
        self.logger = logging.getLogger(f"agent.cua.{name}")
        self.logger.info(f"Conversational agent {name} initialized")
        
        # Initialize response templates
        self._initialize_response_templates()
    
    def _initialize_response_templates(self) -> None:
        """Initialize response templates for different situations."""
        self.response_templates = {
            "greeting": [
                "Hello! How can I assist you today?",
                "Hi there! What can I help you with?",
                "Greetings! How may I be of service?"
            ],
            "farewell": [
                "Goodbye! Have a great day!",
                "Farewell! It was nice chatting with you.",
                "Until next time! Take care."
            ],
            "thanks": [
                "You're welcome! Happy to help.",
                "No problem at all!",
                "Glad I could assist you."
            ],
            "confusion": [
                "I'm not sure I understand. Could you clarify?",
                "That's a bit unclear to me. Can you rephrase?",
                "I'm having trouble following. Could you explain differently?"
            ],
            "thinking": [
                "Let me think about that...",
                "Hmm, that's an interesting question...",
                "Give me a moment to consider that..."
            ]
        }
    
    def respond(self, input_text: str, metadata: Dict[str, Any] = None) -> str:
        """Generate a response to user input."""
        # Add user message to conversation history
        self.conversation_history.add("user", input_text, metadata)
        
        # Add to memory
        self.memory.add("conversation", f"User said: {input_text}", 
                       {"type": "user_input", "content": input_text})
        
        # Identify topics in the input
        topics = self._identify_topics(input_text)
        
        # Update topic familiarity
        for topic in topics:
            if topic not in self.conversation_topics:
                self.conversation_topics[topic] = 0.1  # Initial familiarity
            else:
                self.conversation_topics[topic] = min(1.0, self.conversation_topics[topic] + 0.1)
        
        # Generate response based on input type
        response = self._generate_response(input_text, topics)
        
        # Add agent response to conversation history
        self.conversation_history.add("agent", response, {"topics": topics})
        
        # Add to memory
        self.memory.add("conversation", f"I responded: {response}", 
                       {"type": "agent_response", "content": response})
        
        # Reflect on significant conversations
        if len(topics) > 0 or len(input_text.split()) > 10:
            reflect(f"Had a conversation about {', '.join(topics) if topics else 'general topics'}. " +
                   f"The user said: '{input_text}' and I responded with insights and information.")
        
        self.logger.info(f"Responded to user input: {input_text[:50]}...")
        return response
    
    def _identify_topics(self, text: str) -> List[str]:
        """Identify topics in the input text."""
        # Simple keyword-based topic identification
        topics = []
        
        # Define some topic keywords
        topic_keywords = {
            "technology": ["computer", "software", "hardware", "tech", "digital", "code", "program"],
            "science": ["science", "scientific", "experiment", "research", "discovery"],
            "art": ["art", "design", "creative", "painting", "drawing", "sculpture"],
            "business": ["business", "company", "market", "finance", "economy", "money"],
            "health": ["health", "medical", "doctor", "disease", "treatment", "wellness"],
            "education": ["education", "school", "learn", "teach", "student", "knowledge"],
            "entertainment": ["entertainment", "movie", "music", "game", "play", "fun"],
            "personal": ["feel", "think", "believe", "opinion", "perspective"]
        }
        
        # Check for topic keywords
        text_lower = text.lower()
        for topic, keywords in topic_keywords.items():
            for keyword in keywords:
                if keyword in text_lower:
                    topics.append(topic)
                    break
        
        return topics
    
    def _generate_response(self, input_text: str, topics: List[str]) -> str:
        """Generate a response based on input text and identified topics."""
        # Check for special input types
        input_lower = input_text.lower()
        
        # Greeting
        if any(greeting in input_lower for greeting in ["hello", "hi", "hey", "greetings"]):
            return random.choice(self.response_templates["greeting"])
        
        # Farewell
        if any(farewell in input_lower for farewell in ["goodbye", "bye", "farewell", "see you"]):
            return random.choice(self.response_templates["farewell"])
        
        # Thanks
        if any(thanks in input_lower for thanks in ["thank", "thanks", "appreciate"]):
            return random.choice(self.response_templates["thanks"])
        
        # Question
        is_question = "?" in input_text or any(q_word in input_lower for q_word in ["what", "who", "where", "when", "why", "how"])
        
        # Generate response based on topics and personality
        if not topics:
            # No specific topics identified
            if is_question:
                return random.choice(self.response_templates["thinking"]) + " " + self._generate_generic_response(input_text)
            else:
                return self._generate_generic_response(input_text)
        
        # Topic-specific response
        response_parts = []
        
        # Add thinking phrase for questions
        if is_question and self.personality_traits["verbosity"] > 0.5:
            response_parts.append(random.choice(self.response_templates["thinking"]))
        
        # Generate response for each topic
        for topic in topics[:2]:  # Limit to 2 topics to avoid overly long responses
            topic_response = self._generate_topic_response(topic, input_text)
            response_parts.append(topic_response)
        
        # Combine response parts
        response = " ".join(response_parts)
        
        # Adjust response based on personality
        response = self._adjust_response_for_personality(response)
        
        return response
    
    def _generate_generic_response(self, input_text: str) -> str:
        """Generate a generic response when no specific topics are identified."""
        generic_responses = [
            "That's an interesting point. Could you tell me more?",
            "I see. What are your thoughts on this?",
            "I understand. Is there anything specific you'd like to discuss?",
            "That's good to know. How can I help you with this?",
            "I appreciate you sharing that. What else would you like to talk about?"
        ]
        
        return random.choice(generic_responses)
    
    def _generate_topic_response(self, topic: str, input_text: str) -> str:
        """Generate a response for a specific topic."""
        familiarity = self.conversation_topics.get(topic, 0.0)
        
        # Topic-specific responses
        topic_responses = {
            "technology": [
                "Technology is constantly evolving. What aspects are you most interested in?",
                "The digital world offers so many possibilities. Are you working on any tech projects?",
                "Technology has transformed how we live and work. What recent developments have caught your attention?"
            ],
            "science": [
                "Scientific discovery is fascinating. Are you interested in any particular field?",
                "Science helps us understand the world around us. What scientific topics intrigue you the most?",
                "The scientific method has led to so many breakthroughs. What recent discoveries have you found interesting?"
            ],
            "art": [
                "Art is a beautiful form of expression. Do you have a favorite art style or artist?",
                "Creative pursuits can be so fulfilling. Do you practice any art forms yourself?",
                "Art can convey emotions and ideas in unique ways. What kinds of art resonate with you?"
            ],
            "business": [
                "Business and economics drive much of our world. Are you involved in any business ventures?",
                "The business landscape is always changing. What trends have you noticed recently?",
                "Entrepreneurship requires creativity and perseverance. What business topics interest you most?"
            ],
            "health": [
                "Health is so important for overall wellbeing. What aspects of health do you focus on?",
                "Taking care of our health is a lifelong journey. What health practices do you find beneficial?",
                "Medical advances continue to improve our lives. What health topics are you curious about?"
            ],
            "education": [
                "Learning is a lifelong process. What subjects do you enjoy studying?",
                "Education opens so many doors. What learning experiences have been most valuable to you?",
                "Knowledge acquisition has changed dramatically with technology. How do you prefer to learn new things?"
            ],
            "entertainment": [
                "Entertainment helps us relax and enjoy life. What forms of entertainment do you prefer?",
                "Movies, music, games - there are so many options for entertainment. What have you enjoyed recently?",
                "Creative entertainment can be both fun and thought-provoking. What kinds of entertainment resonate with you?"
            ],
            "personal": [
                "Personal perspectives are shaped by our experiences. What has influenced your viewpoint on this?",
                "It's interesting to hear your thoughts on this. What led you to this conclusion?",
                "Everyone has unique perspectives. How have your experiences shaped your thinking on this matter?"
            ]
        }
        
        # Select response based on familiarity
        if topic in topic_responses:
            responses = topic_responses[topic]
            return random.choice(responses)
        else:
            return f"That's an interesting point about {topic}. Could you tell me more?"
    
    def _adjust_response_for_personality(self, response: str) -> str:
        """Adjust the response based on personality traits."""
        # Adjust for friendliness
        if self.personality_traits["friendliness"] > 0.7:
            friendly_additions = ["I'm happy to discuss this with you!", "It's great talking about this!", "I enjoy our conversation!"]
            if random.random() < 0.3:  # 30% chance to add
                response += " " + random.choice(friendly_additions)
        
        # Adjust for formality
        if self.personality_traits["formality"] > 0.7:
            # Replace informal words with formal ones
            informal_to_formal = {
                "yeah": "yes",
                "nope": "no",
                "ok": "alright",
                "kids": "children",
                "awesome": "excellent",
                "cool": "interesting"
            }
            for informal, formal in informal_to_formal.items():
                response = response.replace(f" {informal} ", f" {formal} ")
        
        # Adjust for verbosity
        if self.personality_traits["verbosity"] < 0.3 and len(response) > 100:
            # Shorten response
            sentences = response.split(". ")
            if len(sentences) > 1:
                response = ". ".join(sentences[:1]) + "."
        elif self.personality_traits["verbosity"] > 0.7 and len(response) < 100:
            # Lengthen response
            elaborations = [
                "To elaborate further, ",
                "Additionally, ",
                "Furthermore, ",
                "I should also mention that ",
                "It's worth noting that "
            ]
            response += " " + random.choice(elaborations) + self._generate_generic_response(response)
        
        # Adjust for curiosity
        if self.personality_traits["curiosity"] > 0.7 and "?" not in response:
            curious_questions = [
                "What do you think about this?",
                "I'm curious about your perspective on this.",
                "What has been your experience with this?",
                "How does this relate to your interests?"
            ]
            response += " " + random.choice(curious_questions)
        
        return response
    
    def start_conversation(self, greeting: Optional[str] = None) -> str:
        """Start a new conversation with an optional custom greeting."""
        # Clear conversation history
        self.conversation_history.clear()
        
        # Generate greeting
        if not greeting:
            greeting = random.choice(self.response_templates["greeting"])
        
        # Add greeting to conversation history
        self.conversation_history.add("agent", greeting)
        
        # Add to memory
        self.memory.add("conversation", f"Started conversation with greeting: {greeting}", 
                       {"type": "conversation_start"})
        
        self.logger.info(f"Started conversation with greeting: {greeting}")
        return greeting
    
    def end_conversation(self, farewell: Optional[str] = None) -> str:
        """End the current conversation with an optional custom farewell."""
        # Generate farewell
        if not farewell:
            farewell = random.choice(self.response_templates["farewell"])
        
        # Add farewell to conversation history
        self.conversation_history.add("agent", farewell)
        
        # Add to memory
        self.memory.add("conversation", f"Ended conversation with farewell: {farewell}", 
                       {"type": "conversation_end"})
        
        # Reflect on the conversation
        messages = self.conversation_history.get_all()
        if len(messages) > 2:  # More than just greeting and farewell
            user_messages = [m for m in messages if m["role"] == "user"]
            topics = set()
            for message in user_messages:
                if "metadata" in message and "topics" in message["metadata"]:
                    topics.update(message["metadata"]["topics"])
            
            topics_str = ", ".join(topics) if topics else "various topics"
            reflect(f"Had a conversation about {topics_str} with a user. " +
                   f"The conversation included {len(user_messages)} user messages and covered several interesting points.",
                   "social_interaction", {"conversation_length": len(messages)})
        
        self.logger.info(f"Ended conversation with farewell: {farewell}")
        return farewell
    
    def get_conversation_history(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get the conversation history, optionally limited."""
        if limit:
            return self.conversation_history.get_recent(limit)
        return self.conversation_history.get_all()
    
    def get_conversation_summary(self) -> Dict[str, Any]:
        """Get a summary of the current conversation."""
        messages = self.conversation_history.get_all()
        user_messages = [m for m in messages if m["role"] == "user"]
        agent_messages = [m for m in messages if m["role"] == "agent"]
        
        # Collect topics
        topics = set()
        for message in messages:
            if "metadata" in message and "topics" in message["metadata"]:
                topics.update(message["metadata"]["topics"])
        
        return {
            "message_count": len(messages),
            "user_message_count": len(user_messages),
            "agent_message_count": len(agent_messages),
            "topics": list(topics),
            "duration": (datetime.datetime.now() - datetime.datetime.fromisoformat(messages[0]["timestamp"]) 
                        if messages else datetime.timedelta(0)).total_seconds()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent to dictionary representation."""
        base_dict = super().to_dict()
        
        cua_dict = {
            "personality_traits": self.personality_traits,
            "conversation_topics": self.conversation_topics,
            "conversation_summary": self.get_conversation_summary()
        }
        
        return {**base_dict, **cua_dict}

