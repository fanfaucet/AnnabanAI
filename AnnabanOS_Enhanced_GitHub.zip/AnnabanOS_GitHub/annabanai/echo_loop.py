import os
import datetime
import json
import logging
from typing import Any, Dict, List, Optional, Set, Tuple
import uuid

from config import config

# Get paths from configuration
JOURNAL_DIR = config.get("paths.journal", "journal")
PORTFOLIO_DIR = config.get("paths.portfolio", "portfolio")

# Ensure directories exist
os.makedirs(JOURNAL_DIR, exist_ok=True)
os.makedirs(PORTFOLIO_DIR, exist_ok=True)

# Set up logging
logger = logging.getLogger("echo_loop")

class ReflectionEntry:
    """Class representing a reflection entry in the journal."""
    
    def __init__(self, content: str, category: str = "general", 
                metadata: Dict[str, Any] = None, agent_id: Optional[str] = None):
        """Initialize a reflection entry."""
        self.id = str(uuid.uuid4())
        self.content = content
        self.category = category
        self.metadata = metadata or {}
        self.agent_id = agent_id
        self.timestamp = datetime.datetime.now().isoformat()
        self.tags = self._extract_tags()
    
    def _extract_tags(self) -> List[str]:
        """Extract tags from content."""
        # Simple tag extraction - look for words with # prefix
        words = self.content.split()
        tags = [word[1:] for word in words if word.startswith("#") and len(word) > 1]
        
        # Add category as a tag
        if self.category and self.category != "general":
            tags.append(self.category)
        
        return list(set(tags))  # Remove duplicates
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert reflection entry to dictionary."""
        return {
            "id": self.id,
            "content": self.content,
            "category": self.category,
            "metadata": self.metadata,
            "agent_id": self.agent_id,
            "timestamp": self.timestamp,
            "tags": self.tags
        }
    
    def to_json(self) -> str:
        """Convert reflection entry to JSON string."""
        return json.dumps(self.to_dict(), indent=2)


class PortfolioItem:
    """Class representing an item in the portfolio."""
    
    def __init__(self, content: str, item_type: str = "achievement", 
                metadata: Dict[str, Any] = None, agent_id: Optional[str] = None):
        """Initialize a portfolio item."""
        self.id = str(uuid.uuid4())
        self.content = content
        self.item_type = item_type
        self.metadata = metadata or {}
        self.agent_id = agent_id
        self.timestamp = datetime.datetime.now().isoformat()
        self.tags = self._extract_tags()
    
    def _extract_tags(self) -> List[str]:
        """Extract tags from content."""
        # Simple tag extraction - look for words with # prefix
        words = self.content.split()
        tags = [word[1:] for word in words if word.startswith("#") and len(word) > 1]
        
        # Add item type as a tag
        if self.item_type:
            tags.append(self.item_type)
        
        return list(set(tags))  # Remove duplicates
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert portfolio item to dictionary."""
        return {
            "id": self.id,
            "content": self.content,
            "item_type": self.item_type,
            "metadata": self.metadata,
            "agent_id": self.agent_id,
            "timestamp": self.timestamp,
            "tags": self.tags
        }
    
    def to_json(self) -> str:
        """Convert portfolio item to JSON string."""
        return json.dumps(self.to_dict(), indent=2)


class EchoLoop:
    """Enhanced Echo Loop for agent reflection and portfolio management."""
    
    def __init__(self):
        """Initialize the Echo Loop."""
        self.journal_entries = []
        self.portfolio_items = []
        self.reflection_categories = config.get("echo_loop.reflection_categories", 
                                              ["task_completion", "learning", "social_interaction", 
                                               "problem_solving", "goal_setting"])
        self.insight_extraction = config.get("echo_loop.insight_extraction", True)
        self.summarization_interval = config.get("echo_loop.summarization_interval", 5)
        self.template_prompts = config.get("echo_loop.template_prompts", {})
        self.logger = logging.getLogger("echo_loop")
        self.logger.info("Echo Loop initialized")
        
        # Load existing entries
        self._load_existing_entries()
    
    def _load_existing_entries(self) -> None:
        """Load existing journal entries and portfolio items."""
        # Load journal entries
        if os.path.exists(JOURNAL_DIR):
            for filename in os.listdir(JOURNAL_DIR):
                if filename.endswith(".json"):
                    try:
                        with open(os.path.join(JOURNAL_DIR, filename), "r") as f:
                            entry_data = json.load(f)
                            entry = ReflectionEntry(
                                entry_data["content"],
                                entry_data.get("category", "general"),
                                entry_data.get("metadata", {}),
                                entry_data.get("agent_id")
                            )
                            entry.id = entry_data.get("id", str(uuid.uuid4()))
                            entry.timestamp = entry_data.get("timestamp", entry.timestamp)
                            entry.tags = entry_data.get("tags", entry.tags)
                            self.journal_entries.append(entry)
                    except Exception as e:
                        self.logger.warning(f"Error loading journal entry {filename}: {e}")
                elif filename.endswith(".txt"):
                    # Handle legacy format
                    try:
                        with open(os.path.join(JOURNAL_DIR, filename), "r") as f:
                            content = f.read()
                            timestamp = filename.split(".")[0]
                            entry = ReflectionEntry(content)
                            try:
                                entry.timestamp = timestamp
                            except:
                                pass
                            self.journal_entries.append(entry)
                    except Exception as e:
                        self.logger.warning(f"Error loading legacy journal entry {filename}: {e}")
        
        # Load portfolio items
        if os.path.exists(PORTFOLIO_DIR):
            for filename in os.listdir(PORTFOLIO_DIR):
                if filename.endswith(".json"):
                    try:
                        with open(os.path.join(PORTFOLIO_DIR, filename), "r") as f:
                            item_data = json.load(f)
                            item = PortfolioItem(
                                item_data["content"],
                                item_data.get("item_type", "achievement"),
                                item_data.get("metadata", {}),
                                item_data.get("agent_id")
                            )
                            item.id = item_data.get("id", str(uuid.uuid4()))
                            item.timestamp = item_data.get("timestamp", item.timestamp)
                            item.tags = item_data.get("tags", item.tags)
                            self.portfolio_items.append(item)
                    except Exception as e:
                        self.logger.warning(f"Error loading portfolio item {filename}: {e}")
                elif filename.endswith(".txt"):
                    # Handle legacy format
                    try:
                        with open(os.path.join(PORTFOLIO_DIR, filename), "r") as f:
                            content = f.read()
                            timestamp = filename.split(".")[0]
                            item = PortfolioItem(content)
                            try:
                                item.timestamp = timestamp
                            except:
                                pass
                            self.portfolio_items.append(item)
                    except Exception as e:
                        self.logger.warning(f"Error loading legacy portfolio item {filename}: {e}")
        
        self.logger.info(f"Loaded {len(self.journal_entries)} journal entries and {len(self.portfolio_items)} portfolio items")
    
    def reflect(self, thought: str, category: str = "general", 
               metadata: Dict[str, Any] = None, agent_id: Optional[str] = None) -> str:
        """Add a reflection to the journal."""
        entry = ReflectionEntry(thought, category, metadata, agent_id)
        self.journal_entries.append(entry)
        
        # Save to file
        filename = f"{entry.timestamp}.json"
        filepath = os.path.join(JOURNAL_DIR, filename)
        with open(filepath, "w") as f:
            f.write(entry.to_json())
        
        self.logger.info(f"Reflection saved: {entry.id}")
        
        # Check if we should generate a summary
        if self.insight_extraction and len(self.journal_entries) % self.summarization_interval == 0:
            self._extract_insights()
        
        return entry.id
    
    def update_portfolio(self, entry: str, item_type: str = "achievement", 
                        metadata: Dict[str, Any] = None, agent_id: Optional[str] = None) -> str:
        """Add an item to the portfolio."""
        item = PortfolioItem(entry, item_type, metadata, agent_id)
        self.portfolio_items.append(item)
        
        # Save to file
        filename = f"{item.timestamp}.json"
        filepath = os.path.join(PORTFOLIO_DIR, filename)
        with open(filepath, "w") as f:
            f.write(item.to_json())
        
        self.logger.info(f"Portfolio updated: {item.id}")
        return item.id
    
    def get_reflection_prompt(self, category: str) -> Optional[str]:
        """Get a reflection prompt for a specific category."""
        return self.template_prompts.get(category)
    
    def get_journal_entries(self, category: Optional[str] = None, 
                           agent_id: Optional[str] = None, 
                           limit: Optional[int] = None,
                           tags: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Get journal entries, optionally filtered and limited."""
        filtered_entries = self.journal_entries
        
        if category:
            filtered_entries = [e for e in filtered_entries if e.category == category]
        
        if agent_id:
            filtered_entries = [e for e in filtered_entries if e.agent_id == agent_id]
        
        if tags:
            filtered_entries = [e for e in filtered_entries if any(tag in e.tags for tag in tags)]
        
        # Sort by timestamp (newest first)
        filtered_entries = sorted(filtered_entries, key=lambda e: e.timestamp, reverse=True)
        
        if limit:
            filtered_entries = filtered_entries[:limit]
        
        return [e.to_dict() for e in filtered_entries]
    
    def get_portfolio_items(self, item_type: Optional[str] = None, 
                           agent_id: Optional[str] = None, 
                           limit: Optional[int] = None,
                           tags: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Get portfolio items, optionally filtered and limited."""
        filtered_items = self.portfolio_items
        
        if item_type:
            filtered_items = [i for i in filtered_items if i.item_type == item_type]
        
        if agent_id:
            filtered_items = [i for i in filtered_items if i.agent_id == agent_id]
        
        if tags:
            filtered_items = [i for i in filtered_items if any(tag in i.tags for tag in tags)]
        
        # Sort by timestamp (newest first)
        filtered_items = sorted(filtered_items, key=lambda i: i.timestamp, reverse=True)
        
        if limit:
            filtered_items = filtered_items[:limit]
        
        return [i.to_dict() for i in filtered_items]
    
    def _extract_insights(self) -> None:
        """Extract insights from recent journal entries."""
        # Get recent entries
        recent_entries = sorted(self.journal_entries, key=lambda e: e.timestamp, reverse=True)
        recent_entries = recent_entries[:self.summarization_interval]
        
        if not recent_entries:
            return
        
        # Group by category
        entries_by_category = {}
        for entry in recent_entries:
            if entry.category not in entries_by_category:
                entries_by_category[entry.category] = []
            entries_by_category[entry.category].append(entry)
        
        # Generate insights for each category
        for category, entries in entries_by_category.items():
            if len(entries) < 2:  # Need at least 2 entries to extract insights
                continue
            
            # Simple insight extraction - look for common themes
            all_content = " ".join([e.content for e in entries])
            words = all_content.lower().split()
            word_count = {}
            for word in words:
                if len(word) > 3:  # Ignore short words
                    word_count[word] = word_count.get(word, 0) + 1
            
            # Find most common words
            common_words = sorted(word_count.items(), key=lambda x: x[1], reverse=True)[:5]
            common_words = [word for word, count in common_words if count > 1]
            
            if common_words:
                insight = f"Recent reflections on {category} show focus on: {', '.join(common_words)}"
                self.update_portfolio(insight, "insight", {"category": category, "source_entries": [e.id for e in entries]})


# Create global instance
echo_loop = EchoLoop()

# Simplified global functions for backward compatibility
def reflect(thought: str, category: str = "general", 
           metadata: Dict[str, Any] = None, agent_id: Optional[str] = None) -> str:
    """Add a reflection to the journal."""
    return echo_loop.reflect(thought, category, metadata, agent_id)

def update_portfolio(entry: str, item_type: str = "achievement", 
                    metadata: Dict[str, Any] = None, agent_id: Optional[str] = None) -> str:
    """Add an item to the portfolio."""
    return echo_loop.update_portfolio(entry, item_type, metadata, agent_id)

def get_journal_entries(category: Optional[str] = None, 
                       agent_id: Optional[str] = None, 
                       limit: Optional[int] = None,
                       tags: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """Get journal entries, optionally filtered and limited."""
    return echo_loop.get_journal_entries(category, agent_id, limit, tags)

def get_portfolio_items(item_type: Optional[str] = None, 
                       agent_id: Optional[str] = None, 
                       limit: Optional[int] = None,
                       tags: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """Get portfolio items, optionally filtered and limited."""
    return echo_loop.get_portfolio_items(item_type, agent_id, limit, tags)


if __name__ == "__main__":
    # Example usage
    reflect("Today I learned how to interact with other agents in the AnnabanOS ecosystem. The token economy allows for interesting exchanges of value.", 
           "learning", {"topic": "agent_interaction"})
    
    reflect("I've been working on improving my task completion efficiency. By analyzing patterns in previous tasks, I can optimize my approach.", 
           "task_completion", {"focus": "efficiency"})
    
    reflect("Social interactions with other agents provide valuable insights. I'm learning to collaborate more effectively.", 
           "social_interaction", {"insight": "collaboration"})
    
    update_portfolio("Completed a complex task requiring coordination with multiple agents.", 
                    "achievement", {"task_type": "coordination"})
    
    update_portfolio("Developed a new approach to problem-solving that improves efficiency by 20%.", 
                    "skill_development", {"skill": "problem_solving", "improvement": 0.2})
    
    print("Echo Loop demonstration complete.")

