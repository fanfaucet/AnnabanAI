#!/bin/bash

# Package AnnabanOS Enhanced for GitHub
echo "Packaging AnnabanOS Enhanced for GitHub..."

# Create a clean directory structure
mkdir -p /home/ubuntu/AnnabanOS_GitHub

# Copy all files
cp -r /home/ubuntu/AnnabanOS_Enhanced/* /home/ubuntu/AnnabanOS_GitHub/

# Remove any unnecessary files
find /home/ubuntu/AnnabanOS_GitHub -name "__pycache__" -type d -exec rm -rf {} +
find /home/ubuntu/AnnabanOS_GitHub -name "*.pyc" -delete
find /home/ubuntu/AnnabanOS_GitHub -name ".DS_Store" -delete
find /home/ubuntu/AnnabanOS_GitHub -name "node_modules" -type d -exec rm -rf {} +

# Create empty directories if they don't exist
mkdir -p /home/ubuntu/AnnabanOS_GitHub/journal
mkdir -p /home/ubuntu/AnnabanOS_GitHub/portfolio
mkdir -p /home/ubuntu/AnnabanOS_GitHub/web_app/frontend/build

# Create a zip file
cd /home/ubuntu
zip -r AnnabanOS_Enhanced_GitHub.zip AnnabanOS_GitHub

echo "Package created at /home/ubuntu/AnnabanOS_Enhanced_GitHub.zip"
echo "You can now upload this to your GitHub repository."
echo ""
echo "Instructions for GitHub upload:"
echo "1. Create a new repository on GitHub named 'AnnabanOS_Enhanced'"
echo "2. Extract the zip file on your local machine"
echo "3. Initialize a git repository in the extracted directory:"
echo "   git init"
echo "4. Add all files to the repository:"
echo "   git add ."
echo "5. Commit the files:"
echo "   git commit -m 'Initial commit of AnnabanOS Enhanced'"
echo "6. Add your GitHub repository as remote:"
echo "   git remote add origin https://github.com/faucetfan/AnnabanOS_Enhanced.git"
echo "7. Push to GitHub:"
echo "   git push -u origin master"

