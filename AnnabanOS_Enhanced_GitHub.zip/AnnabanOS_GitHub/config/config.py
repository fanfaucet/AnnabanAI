import os
import yaml
import logging
from typing import Any, Dict, Optional

class Config:
    """Configuration manager for AnnabanOS Enhanced.
    
    This class loads configuration from a YAML file and provides
    methods to access configuration values. It also supports
    environment variable overrides.
    """
    
    _instance = None
    
    def __new__(cls):
        """Singleton pattern to ensure only one config instance exists."""
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        """Initialize the configuration manager."""
        if self._initialized:
            return
            
        self.logger = logging.getLogger(__name__)
        self.config_path = os.environ.get("ANNABAN_CONFIG", "config/config.yaml")
        self.config = {}
        self._load_config()
        self._initialized = True
    
    def _load_config(self) -> None:
        """Load configuration from YAML file."""
        try:
            with open(self.config_path, "r") as f:
                self.config = yaml.safe_load(f)
            self.logger.info(f"Configuration loaded from {self.config_path}")
        except Exception as e:
            self.logger.error(f"Error loading configuration: {e}")
            self.config = {}
        
        # Override with environment variables
        self._apply_env_overrides()
    
    def _apply_env_overrides(self) -> None:
        """Apply environment variable overrides to configuration."""
        prefix = "ANNABAN_"
        for env_var, value in os.environ.items():
            if env_var.startswith(prefix):
                # Convert ANNABAN_TOKEN_ECONOMY_INTEREST_RATE to token_economy.interest_rate
                config_path = env_var[len(prefix):].lower().replace("_", ".")
                self._set_nested_value(config_path, value)
    
    def _set_nested_value(self, path: str, value: str) -> None:
        """Set a nested configuration value from a dot-separated path."""
        keys = path.split(".")
        current = self.config
        
        # Navigate to the innermost dict
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        # Set the value, converting to appropriate type
        current[keys[-1]] = self._convert_value_type(value)
    
    def _convert_value_type(self, value: str) -> Any:
        """Convert string value to appropriate type."""
        # Try to convert to int
        try:
            return int(value)
        except ValueError:
            pass
        
        # Try to convert to float
        try:
            return float(value)
        except ValueError:
            pass
        
        # Convert boolean strings
        if value.lower() in ("true", "yes", "1"):
            return True
        if value.lower() in ("false", "no", "0"):
            return False
        
        # Default to string
        return value
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value by dot-separated path."""
        keys = key.split(".")
        value = self.config
        
        # Navigate the nested dictionaries
        for k in keys:
            if not isinstance(value, dict) or k not in value:
                return default
            value = value[k]
        
        return value
    
    def set(self, key: str, value: Any) -> None:
        """Set a configuration value by dot-separated path."""
        self._set_nested_value(key, value)
    
    def reload(self) -> None:
        """Reload configuration from file."""
        self._load_config()
    
    def save(self, path: Optional[str] = None) -> None:
        """Save current configuration to file."""
        save_path = path or self.config_path
        try:
            with open(save_path, "w") as f:
                yaml.dump(self.config, f, default_flow_style=False)
            self.logger.info(f"Configuration saved to {save_path}")
        except Exception as e:
            self.logger.error(f"Error saving configuration: {e}")
    
    def get_all(self) -> Dict[str, Any]:
        """Get the entire configuration dictionary."""
        return self.config


# Initialize logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

# Create a global config instance
config = Config()

