import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  Typography, 
  Button,
  List,
  ListItem,
  ListItemText,
  Divider,
  CircularProgress
} from '@mui/material';
import { 
  getAgents, 
  getJournalEntries, 
  getPortfolioItems, 
  getTokenBalances,
  runSimulation
} from '../services/api';
import { Doughnut, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title } from 'chart.js';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

const Dashboard = ({ systemInfo }) => {
  const [agents, setAgents] = useState({});
  const [journalEntries, setJournalEntries] = useState([]);
  const [portfolioItems, setPortfolioItems] = useState([]);
  const [tokenBalances, setTokenBalances] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [simulationRunning, setSimulationRunning] = useState(false);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [agentsData, journalData, portfolioData, balancesData] = await Promise.all([
          getAgents(),
          getJournalEntries({ limit: 5 }),
          getPortfolioItems({ limit: 5 }),
          getTokenBalances()
        ]);
        
        setAgents(agentsData);
        setJournalEntries(journalData);
        setPortfolioItems(portfolioData);
        setTokenBalances(balancesData);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const handleRunSimulation = async () => {
    setSimulationRunning(true);
    try {
      await runSimulation({ cycles: 1 });
      
      // Refresh data after simulation
      const [agentsData, journalData, portfolioData, balancesData] = await Promise.all([
        getAgents(),
        getJournalEntries({ limit: 5 }),
        getPortfolioItems({ limit: 5 }),
        getTokenBalances()
      ]);
      
      setAgents(agentsData);
      setJournalEntries(journalData);
      setPortfolioItems(portfolioData);
      setTokenBalances(balancesData);
    } catch (err) {
      console.error('Error running simulation:', err);
      setError('Failed to run simulation. Please try again later.');
    } finally {
      setSimulationRunning(false);
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography variant="h4" color="error" gutterBottom>
          Error
        </Typography>
        <Typography variant="body1">{error}</Typography>
        <Button variant="contained" onClick={() => window.location.reload()} sx={{ mt: 2 }}>
          Retry
        </Button>
      </Box>
    );
  }

  // Prepare data for token distribution chart
  const tokenData = {
    labels: Object.values(tokenBalances).map(balance => balance.agent_name),
    datasets: [
      {
        label: 'Token Balance',
        data: Object.values(tokenBalances).map(balance => balance.balance),
        backgroundColor: [
          'rgba(75, 139, 190, 0.6)',
          'rgba(255, 212, 59, 0.6)',
          'rgba(60, 179, 113, 0.6)',
          'rgba(255, 107, 107, 0.6)',
          'rgba(147, 112, 219, 0.6)',
        ],
        borderColor: [
          'rgba(75, 139, 190, 1)',
          'rgba(255, 212, 59, 1)',
          'rgba(60, 179, 113, 1)',
          'rgba(255, 107, 107, 1)',
          'rgba(147, 112, 219, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  // Prepare data for agent types chart
  const agentTypes = Object.values(agents).reduce((acc, agent) => {
    const type = agent.type || 'Unknown';
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {});

  const agentTypeData = {
    labels: Object.keys(agentTypes),
    datasets: [
      {
        label: 'Agent Types',
        data: Object.values(agentTypes),
        backgroundColor: [
          'rgba(75, 139, 190, 0.6)',
          'rgba(255, 212, 59, 0.6)',
          'rgba(60, 179, 113, 0.6)',
        ],
        borderColor: [
          'rgba(75, 139, 190, 1)',
          'rgba(255, 212, 59, 1)',
          'rgba(60, 179, 113, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          Dashboard
        </Typography>
        <Button 
          variant="contained" 
          onClick={handleRunSimulation}
          disabled={simulationRunning}
        >
          {simulationRunning ? 'Running...' : 'Run Simulation Cycle'}
        </Button>
      </Box>

      {/* System Overview */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Agents
              </Typography>
              <Typography variant="h3" color="primary">
                {Object.keys(agents).length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Active in the system
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Token Economy
              </Typography>
              <Typography variant="h3" color="primary">
                {Object.values(tokenBalances).reduce((sum, balance) => sum + balance.balance, 0).toFixed(1)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Total tokens in circulation
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Journal Entries
              </Typography>
              <Typography variant="h3" color="primary">
                {journalEntries.length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Reflections & thoughts
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Portfolio Items
              </Typography>
              <Typography variant="h3" color="primary">
                {portfolioItems.length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Achievements & skills
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Charts and Activity */}
      <Grid container spacing={3}>
        {/* Token Distribution Chart */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Token Distribution
              </Typography>
              <Box sx={{ height: 300, display: 'flex', justifyContent: 'center' }}>
                <Doughnut 
                  data={tokenData} 
                  options={{ 
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                      },
                    },
                  }} 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Agent Types Chart */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Agent Types
              </Typography>
              <Box sx={{ height: 300, display: 'flex', justifyContent: 'center' }}>
                <Bar 
                  data={agentTypeData} 
                  options={{ 
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                  }} 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Activity */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Journal Entries
              </Typography>
              <List>
                {journalEntries.length > 0 ? (
                  journalEntries.map((entry, index) => (
                    <React.Fragment key={entry.id || index}>
                      <ListItem alignItems="flex-start">
                        <ListItemText
                          primary={entry.category ? entry.category.charAt(0).toUpperCase() + entry.category.slice(1) : 'Entry'}
                          secondary={
                            <>
                              <Typography
                                component="span"
                                variant="body2"
                                color="text.primary"
                              >
                                {entry.timestamp ? new Date(entry.timestamp).toLocaleString() : 'Unknown time'}
                              </Typography>
                              {` — ${entry.content}`}
                            </>
                          }
                        />
                      </ListItem>
                      {index < journalEntries.length - 1 && <Divider />}
                    </React.Fragment>
                  ))
                ) : (
                  <Typography variant="body2" color="text.secondary">
                    No journal entries found.
                  </Typography>
                )}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Portfolio Items */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Portfolio Items
              </Typography>
              <List>
                {portfolioItems.length > 0 ? (
                  portfolioItems.map((item, index) => (
                    <React.Fragment key={item.id || index}>
                      <ListItem alignItems="flex-start">
                        <ListItemText
                          primary={item.item_type ? item.item_type.charAt(0).toUpperCase() + item.item_type.slice(1) : 'Item'}
                          secondary={
                            <>
                              <Typography
                                component="span"
                                variant="body2"
                                color="text.primary"
                              >
                                {item.timestamp ? new Date(item.timestamp).toLocaleString() : 'Unknown time'}
                              </Typography>
                              {` — ${item.content}`}
                            </>
                          }
                        />
                      </ListItem>
                      {index < portfolioItems.length - 1 && <Divider />}
                    </React.Fragment>
                  ))
                ) : (
                  <Typography variant="body2" color="text.secondary">
                    No portfolio items found.
                  </Typography>
                )}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;

