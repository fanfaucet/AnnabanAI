import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || '/api';

// System
export const getSystemInfo = async () => {
  const response = await axios.get(`${API_URL}/system/info`);
  return response.data;
};

// Agents
export const getAgents = async () => {
  const response = await axios.get(`${API_URL}/agents`);
  return response.data;
};

export const getAgent = async (agentId) => {
  const response = await axios.get(`${API_URL}/agents/${agentId}`);
  return response.data;
};

// Collectives
export const getCollectives = async () => {
  const response = await axios.get(`${API_URL}/collectives`);
  return response.data;
};

export const getCollective = async (collectiveId) => {
  const response = await axios.get(`${API_URL}/collectives/${collectiveId}`);
  return response.data;
};

// Journal
export const getJournalEntries = async (params = {}) => {
  const response = await axios.get(`${API_URL}/journal`, { params });
  return response.data;
};

export const addJournalEntry = async (entry) => {
  const response = await axios.post(`${API_URL}/journal`, entry);
  return response.data;
};

// Portfolio
export const getPortfolioItems = async (params = {}) => {
  const response = await axios.get(`${API_URL}/portfolio`, { params });
  return response.data;
};

export const addPortfolioItem = async (item) => {
  const response = await axios.post(`${API_URL}/portfolio`, item);
  return response.data;
};

// Token Economy
export const getTokenBalances = async () => {
  const response = await axios.get(`${API_URL}/token-economy/balances`);
  return response.data;
};

export const getTokenTransactions = async (params = {}) => {
  const response = await axios.get(`${API_URL}/token-economy/transactions`, { params });
  return response.data;
};

export const transferTokens = async (transfer) => {
  const response = await axios.post(`${API_URL}/token-economy/transfer`, transfer);
  return response.data;
};

// Marketplace
export const getMarketplaceListings = async (params = {}) => {
  const response = await axios.get(`${API_URL}/marketplace/listings`, { params });
  return response.data;
};

export const createMarketplaceListing = async (listing) => {
  const response = await axios.post(`${API_URL}/marketplace/listings`, listing);
  return response.data;
};

export const purchaseListing = async (purchase) => {
  const response = await axios.post(`${API_URL}/marketplace/purchase`, purchase);
  return response.data;
};

// Virtual World
export const getVirtualWorldMap = async () => {
  const response = await axios.get(`${API_URL}/virtual-world/map`);
  return response.data;
};

export const moveAgent = async (move) => {
  const response = await axios.post(`${API_URL}/virtual-world/move-agent`, move);
  return response.data;
};

// Chat
export const chatWithAgent = async (chat) => {
  const response = await axios.post(`${API_URL}/chat`, chat);
  return response.data;
};

// Simulation
export const runSimulation = async (params = {}) => {
  const response = await axios.post(`${API_URL}/simulate`, params);
  return response.data;
};

