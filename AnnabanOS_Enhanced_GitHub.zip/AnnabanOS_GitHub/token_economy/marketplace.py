import logging
import datetime
from typing import Any, Dict, List, Optional, Tuple
import uuid

from config import config
from token_economy.token_manager import TokenManager

class MarketListing:
    """Class representing a listing in the token marketplace."""
    
    def __init__(self, seller_id: str, title: str, description: str, price: float, 
                category: str, properties: Dict[str, Any] = None):
        """Initialize a market listing."""
        self.id = str(uuid.uuid4())
        self.seller_id = seller_id
        self.title = title
        self.description = description
        self.price = price
        self.category = category
        self.properties = properties or {}
        self.active = True
        self.created_at = datetime.datetime.now().isoformat()
        self.updated_at = self.created_at
    
    def update(self, title: Optional[str] = None, description: Optional[str] = None, 
              price: Optional[float] = None, properties: Optional[Dict[str, Any]] = None) -> None:
        """Update the listing details."""
        if title is not None:
            self.title = title
        if description is not None:
            self.description = description
        if price is not None:
            self.price = price
        if properties is not None:
            self.properties.update(properties)
        
        self.updated_at = datetime.datetime.now().isoformat()
    
    def deactivate(self) -> None:
        """Deactivate the listing."""
        self.active = False
        self.updated_at = datetime.datetime.now().isoformat()
    
    def activate(self) -> None:
        """Activate the listing."""
        self.active = True
        self.updated_at = datetime.datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert listing to dictionary."""
        return {
            "id": self.id,
            "seller_id": self.seller_id,
            "title": self.title,
            "description": self.description,
            "price": self.price,
            "category": self.category,
            "properties": self.properties,
            "active": self.active,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }


class MarketTransaction:
    """Class representing a transaction in the token marketplace."""
    
    def __init__(self, listing_id: str, buyer_id: str, seller_id: str, price: float):
        """Initialize a market transaction."""
        self.id = str(uuid.uuid4())
        self.listing_id = listing_id
        self.buyer_id = buyer_id
        self.seller_id = seller_id
        self.price = price
        self.timestamp = datetime.datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert transaction to dictionary."""
        return {
            "id": self.id,
            "listing_id": self.listing_id,
            "buyer_id": self.buyer_id,
            "seller_id": self.seller_id,
            "price": self.price,
            "timestamp": self.timestamp
        }


class TokenMarketplace:
    """Class representing a marketplace for token-based exchanges."""
    
    def __init__(self, token_manager: TokenManager):
        """Initialize the token marketplace."""
        self.token_manager = token_manager
        self.listings = {}  # listing_id -> MarketListing
        self.transactions = []  # List of MarketTransaction
        self.categories = set()  # Set of available categories
        self.commission_rate = config.get("token_economy.marketplace_commission", 0.05)  # 5%
        self.created_at = datetime.datetime.now().isoformat()
        self.logger = logging.getLogger("token_marketplace")
        self.logger.info("Token marketplace initialized")
        
        # Initialize default categories
        self._initialize_default_categories()
    
    def _initialize_default_categories(self) -> None:
        """Initialize default marketplace categories."""
        default_categories = [
            "task_service",
            "information",
            "social_service",
            "skill_training",
            "resource_access",
            "collaboration"
        ]
        
        for category in default_categories:
            self.categories.add(category)
    
    def create_listing(self, seller_id: str, title: str, description: str, price: float, 
                      category: str, properties: Dict[str, Any] = None) -> Optional[str]:
        """Create a new listing in the marketplace."""
        if price <= 0:
            self.logger.warning(f"Cannot create listing with non-positive price: {price}")
            return None
        
        # Add category if it doesn't exist
        if category not in self.categories:
            self.categories.add(category)
        
        # Create listing
        listing = MarketListing(seller_id, title, description, price, category, properties)
        self.listings[listing.id] = listing
        
        self.logger.info(f"Created listing: {title} by {seller_id} for {price} {self.token_manager.currency_name}")
        return listing.id
    
    def update_listing(self, listing_id: str, seller_id: str, title: Optional[str] = None, 
                      description: Optional[str] = None, price: Optional[float] = None, 
                      properties: Optional[Dict[str, Any]] = None) -> bool:
        """Update an existing listing."""
        if listing_id not in self.listings:
            self.logger.warning(f"Listing {listing_id} not found")
            return False
        
        listing = self.listings[listing_id]
        
        # Check if seller is the owner
        if listing.seller_id != seller_id:
            self.logger.warning(f"Seller {seller_id} is not the owner of listing {listing_id}")
            return False
        
        # Update listing
        listing.update(title, description, price, properties)
        
        self.logger.info(f"Updated listing {listing_id}")
        return True
    
    def deactivate_listing(self, listing_id: str, seller_id: str) -> bool:
        """Deactivate a listing."""
        if listing_id not in self.listings:
            self.logger.warning(f"Listing {listing_id} not found")
            return False
        
        listing = self.listings[listing_id]
        
        # Check if seller is the owner
        if listing.seller_id != seller_id:
            self.logger.warning(f"Seller {seller_id} is not the owner of listing {listing_id}")
            return False
        
        # Deactivate listing
        listing.deactivate()
        
        self.logger.info(f"Deactivated listing {listing_id}")
        return True
    
    def activate_listing(self, listing_id: str, seller_id: str) -> bool:
        """Activate a listing."""
        if listing_id not in self.listings:
            self.logger.warning(f"Listing {listing_id} not found")
            return False
        
        listing = self.listings[listing_id]
        
        # Check if seller is the owner
        if listing.seller_id != seller_id:
            self.logger.warning(f"Seller {seller_id} is not the owner of listing {listing_id}")
            return False
        
        # Activate listing
        listing.activate()
        
        self.logger.info(f"Activated listing {listing_id}")
        return True
    
    def purchase(self, listing_id: str, buyer_id: str) -> bool:
        """Purchase a listing."""
        if listing_id not in self.listings:
            self.logger.warning(f"Listing {listing_id} not found")
            return False
        
        listing = self.listings[listing_id]
        
        # Check if listing is active
        if not listing.active:
            self.logger.warning(f"Listing {listing_id} is not active")
            return False
        
        # Check if buyer has sufficient balance
        buyer_balance = self.token_manager.get_balance(buyer_id)
        if buyer_balance < listing.price:
            self.logger.warning(f"Buyer {buyer_id} has insufficient balance: {buyer_balance} < {listing.price}")
            return False
        
        # Calculate commission
        commission = listing.price * self.commission_rate
        seller_amount = listing.price - commission
        
        # Transfer tokens
        if not self.token_manager.transfer_tokens(buyer_id, listing.seller_id, seller_amount, 
                                                f"Purchase of {listing.title}"):
            self.logger.warning(f"Token transfer failed for purchase of listing {listing_id}")
            return False
        
        # Record transaction
        transaction = MarketTransaction(listing_id, buyer_id, listing.seller_id, listing.price)
        self.transactions.append(transaction)
        
        self.logger.info(f"Buyer {buyer_id} purchased listing {listing_id} from {listing.seller_id} for {listing.price} {self.token_manager.currency_name}")
        return True
    
    def get_active_listings(self, category: Optional[str] = None, 
                          seller_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get active listings, optionally filtered by category and seller."""
        filtered_listings = []
        
        for listing in self.listings.values():
            if not listing.active:
                continue
                
            if category and listing.category != category:
                continue
                
            if seller_id and listing.seller_id != seller_id:
                continue
                
            filtered_listings.append(listing.to_dict())
        
        return filtered_listings
    
    def get_listing(self, listing_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific listing by ID."""
        if listing_id not in self.listings:
            return None
        
        return self.listings[listing_id].to_dict()
    
    def get_seller_listings(self, seller_id: str, active_only: bool = False) -> List[Dict[str, Any]]:
        """Get all listings by a specific seller."""
        seller_listings = []
        
        for listing in self.listings.values():
            if listing.seller_id != seller_id:
                continue
                
            if active_only and not listing.active:
                continue
                
            seller_listings.append(listing.to_dict())
        
        return seller_listings
    
    def get_transaction_history(self, agent_id: Optional[str] = None, 
                              limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get transaction history, optionally filtered by agent and limited."""
        if agent_id:
            filtered_transactions = [t.to_dict() for t in self.transactions 
                                   if t.buyer_id == agent_id or t.seller_id == agent_id]
        else:
            filtered_transactions = [t.to_dict() for t in self.transactions]
        
        if limit:
            return filtered_transactions[-limit:]
        return filtered_transactions
    
    def get_popular_categories(self, limit: int = 5) -> List[Tuple[str, int]]:
        """Get the most popular categories based on transaction count."""
        category_counts = {}
        
        for transaction in self.transactions:
            listing = self.listings.get(transaction.listing_id)
            if not listing:
                continue
                
            category = listing.category
            if category not in category_counts:
                category_counts[category] = 0
            category_counts[category] += 1
        
        sorted_categories = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)
        return sorted_categories[:limit]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert marketplace to dictionary representation."""
        return {
            "active_listings": len([l for l in self.listings.values() if l.active]),
            "total_listings": len(self.listings),
            "transaction_count": len(self.transactions),
            "categories": list(self.categories),
            "commission_rate": self.commission_rate,
            "created_at": self.created_at
        }

