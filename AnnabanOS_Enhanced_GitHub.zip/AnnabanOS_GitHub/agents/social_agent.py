import logging
import datetime
import random
from typing import Any, Dict, List, Optional, Tuple

from agents.base_agent import BaseAgent
from annabanai.echo_loop import reflect, update_portfolio
from config import config

class Relationship:
    """Class representing a relationship between agents."""
    
    def __init__(self, agent_name: str):
        """Initialize a relationship with another agent."""
        self.agent_name = agent_name
        self.strength = 0.0  # 0.0 to 1.0
        self.trust = 0.5     # 0.0 to 1.0
        self.interactions = 0
        self.last_interaction = None
        self.interaction_history = []
        self.tags = []  # e.g., "friend", "collaborator", "mentor"
    
    def update(self, interaction_type: str, value: float) -> None:
        """Update relationship based on an interaction."""
        # Update strength based on interaction type and value
        if interaction_type == "social":
            strength_change = 0.05
        elif interaction_type == "token_transfer":
            strength_change = min(0.2, value / 10.0)  # Cap at 0.2 for large transfers
        elif interaction_type == "collaboration":
            strength_change = 0.1
        elif interaction_type == "conflict":
            strength_change = -0.1
        else:
            strength_change = 0.02  # Default small positive change
        
        self.strength = min(1.0, max(0.0, self.strength + strength_change))
        
        # Update trust based on interaction outcome
        if "positive" in interaction_type:
            trust_change = 0.05
        elif "negative" in interaction_type:
            trust_change = -0.1
        else:
            trust_change = 0.01  # Small default increase
            
        self.trust = min(1.0, max(0.0, self.trust + trust_change))
        
        # Record interaction
        self.interactions += 1
        self.last_interaction = datetime.datetime.now().isoformat()
        
        # Add to history
        self.interaction_history.append({
            "type": interaction_type,
            "value": value,
            "timestamp": self.last_interaction
        })
        
        # Update tags based on relationship strength
        self._update_tags()
    
    def _update_tags(self) -> None:
        """Update relationship tags based on current state."""
        self.tags = []
        
        if self.strength >= 0.8:
            self.tags.append("close friend")
        elif self.strength >= 0.5:
            self.tags.append("friend")
        elif self.strength >= 0.2:
            self.tags.append("acquaintance")
        
        if self.trust >= 0.8:
            self.tags.append("trusted")
        elif self.trust <= 0.2:
            self.tags.append("distrusted")
        
        if self.interactions >= 10:
            self.tags.append("frequent contact")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert relationship to dictionary."""
        return {
            "agent_name": self.agent_name,
            "strength": self.strength,
            "trust": self.trust,
            "interactions": self.interactions,
            "last_interaction": self.last_interaction,
            "tags": self.tags
        }


class SocialNetwork:
    """Class representing a social network of relationships."""
    
    def __init__(self):
        """Initialize an empty social network."""
        self.relationships = {}  # agent_name -> Relationship
    
    def add_relationship(self, agent_name: str) -> Relationship:
        """Add a new relationship to the network."""
        if agent_name not in self.relationships:
            self.relationships[agent_name] = Relationship(agent_name)
        return self.relationships[agent_name]
    
    def get_relationship(self, agent_name: str) -> Optional[Relationship]:
        """Get a relationship by agent name."""
        return self.relationships.get(agent_name)
    
    def update_relationship(self, agent_name: str, interaction_type: str, value: float) -> None:
        """Update a relationship based on an interaction."""
        if agent_name not in self.relationships:
            self.add_relationship(agent_name)
        
        self.relationships[agent_name].update(interaction_type, value)
    
    def get_strongest_relationships(self, limit: int = 5) -> List[Relationship]:
        """Get the strongest relationships in the network."""
        sorted_relationships = sorted(
            self.relationships.values(),
            key=lambda r: r.strength,
            reverse=True
        )
        return sorted_relationships[:limit]
    
    def get_most_trusted(self, limit: int = 5) -> List[Relationship]:
        """Get the most trusted relationships in the network."""
        sorted_relationships = sorted(
            self.relationships.values(),
            key=lambda r: r.trust,
            reverse=True
        )
        return sorted_relationships[:limit]
    
    def get_all_relationships(self) -> Dict[str, Relationship]:
        """Get all relationships in the network."""
        return self.relationships


class SocialAgent(BaseAgent):
    """Enhanced social agent with improved social capabilities."""
    
    def __init__(self, name: str):
        """Initialize the social agent."""
        super().__init__(name)
        self.social_network = SocialNetwork()
        self.friends = []  # Kept for backward compatibility
        self.social_skills = {
            "communication": 0.5,
            "empathy": 0.5,
            "networking": 0.5,
            "persuasion": 0.5,
            "conflict_resolution": 0.5
        }
        self.personality_traits = {
            "extroversion": random.uniform(0.3, 0.8),
            "agreeableness": random.uniform(0.4, 0.9),
            "openness": random.uniform(0.4, 0.8),
            "conscientiousness": random.uniform(0.4, 0.8),
            "neuroticism": random.uniform(0.2, 0.6)
        }
        self.interaction_preferences = {
            "one_on_one": 0.0,
            "small_group": 0.0,
            "large_group": 0.0
        }
        self.logger = logging.getLogger(f"agent.social.{name}")
        self.logger.info(f"Social agent {name} initialized")
    
    def add_friend(self, agent) -> None:
        """Add another agent as a friend."""
        if agent not in self.friends:
            self.friends.append(agent)
            
            # Add to social network
            self.social_network.add_relationship(agent.name)
            
            # Add to memory
            self.memory.add("social", f"Added {agent.name} as a friend", 
                           {"friend_name": agent.name})
            
            # Update relationship in both directions if the other agent is a SocialAgent
            if isinstance(agent, SocialAgent):
                agent.social_network.add_relationship(self.name)
            
            self.logger.info(f"{self.name} added {agent.name} as a friend")
            
            # Reflect on new friendship
            reflect(f"I've formed a new connection with {agent.name}. " +
                   f"Building my social network helps me achieve goals through collaboration.")
    
    def interact(self, specific_friend=None) -> List[Dict[str, Any]]:
        """Interact with friends, either all or a specific one."""
        interaction_results = []
        
        if specific_friend:
            friends_to_interact = [f for f in self.friends if f.name == specific_friend.name]
            if not friends_to_interact:
                self.logger.warning(f"{self.name} tried to interact with non-friend: {specific_friend.name}")
                return []
        else:
            friends_to_interact = self.friends
        
        for friend in friends_to_interact:
            # Determine interaction quality based on social skills and personality
            interaction_quality = self._calculate_interaction_quality(friend)
            
            # Update relationship
            relationship = self.social_network.get_relationship(friend.name)
            if not relationship:
                relationship = self.social_network.add_relationship(friend.name)
            
            interaction_type = "social"
            if interaction_quality > 0.8:
                interaction_type = "social_positive"
            elif interaction_quality < 0.3:
                interaction_type = "social_negative"
            
            relationship.update(interaction_type, interaction_quality)
            
            # Add to memory
            self.memory.add("social", f"Interacted with {friend.name}", 
                           {"friend_name": friend.name, "quality": interaction_quality})
            
            # Update social skills based on interaction
            self._update_social_skills(interaction_quality)
            
            # If friend is a SocialAgent, update their relationship too
            if isinstance(friend, SocialAgent):
                friend_relationship = friend.social_network.get_relationship(self.name)
                if not friend_relationship:
                    friend_relationship = friend.social_network.add_relationship(self.name)
                friend_relationship.update(interaction_type, interaction_quality)
                
                # Add to friend's memory
                friend.memory.add("social", f"Interacted with {self.name}", 
                                {"friend_name": self.name, "quality": interaction_quality})
            
            # Record result
            result = {
                "friend": friend.name,
                "quality": interaction_quality,
                "type": interaction_type,
                "timestamp": datetime.datetime.now().isoformat()
            }
            interaction_results.append(result)
            
            self.logger.info(f"{self.name} interacts with {friend.name} (quality: {interaction_quality:.2f})")
        
        # Reflect on social interactions
        if interaction_results:
            avg_quality = sum(r["quality"] for r in interaction_results) / len(interaction_results)
            if avg_quality > 0.7:
                reflect(f"I had meaningful social interactions today. " +
                       f"These connections strengthen my network and provide emotional support.")
            elif avg_quality < 0.4:
                reflect(f"My social interactions today were challenging. " +
                       f"I need to work on improving my communication and empathy skills.")
        
        return interaction_results
    
    def _calculate_interaction_quality(self, other_agent) -> float:
        """Calculate the quality of an interaction based on agent attributes."""
        # Base quality from social skills
        base_quality = (
            self.social_skills["communication"] * 0.3 +
            self.social_skills["empathy"] * 0.3 +
            self.social_skills["networking"] * 0.2 +
            self.social_skills["persuasion"] * 0.1 +
            self.social_skills["conflict_resolution"] * 0.1
        )
        
        # Adjust for personality compatibility if other agent is a SocialAgent
        personality_factor = 0.0
        if isinstance(other_agent, SocialAgent):
            # Calculate personality compatibility
            compatibility = 0.0
            
            # Similar levels of extroversion tend to work well
            extroversion_diff = abs(self.personality_traits["extroversion"] - 
                                   other_agent.personality_traits["extroversion"])
            compatibility += (1.0 - extroversion_diff) * 0.2
            
            # High agreeableness is generally good for interactions
            agreeableness = (self.personality_traits["agreeableness"] + 
                            other_agent.personality_traits["agreeableness"]) / 2
            compatibility += agreeableness * 0.3
            
            # Openness helps with new relationships
            openness = (self.personality_traits["openness"] + 
                       other_agent.personality_traits["openness"]) / 2
            compatibility += openness * 0.2
            
            # Low neuroticism is better for stable interactions
            neuroticism = (self.personality_traits["neuroticism"] + 
                          other_agent.personality_traits["neuroticism"]) / 2
            compatibility += (1.0 - neuroticism) * 0.3
            
            personality_factor = compatibility
        else:
            # Default moderate compatibility with non-SocialAgents
            personality_factor = 0.6
        
        # Combine factors
        quality = base_quality * 0.7 + personality_factor * 0.3
        
        # Add some randomness to represent day-to-day variation
        quality += random.uniform(-0.1, 0.1)
        
        # Ensure within bounds
        return max(0.1, min(1.0, quality))
    
    def _update_social_skills(self, interaction_quality: float) -> None:
        """Update social skills based on interaction quality."""
        # Determine which skills to improve based on interaction quality
        if interaction_quality > 0.7:
            # Good interactions improve all skills slightly
            for skill in self.social_skills:
                self.social_skills[skill] = min(1.0, self.social_skills[skill] + 0.01)
            
            # Extra improvement to primary skills
            self.social_skills["communication"] = min(1.0, self.social_skills["communication"] + 0.02)
            self.social_skills["empathy"] = min(1.0, self.social_skills["empathy"] + 0.02)
        elif interaction_quality < 0.4:
            # Poor interactions provide opportunity to learn conflict resolution
            self.social_skills["conflict_resolution"] = min(1.0, self.social_skills["conflict_resolution"] + 0.03)
    
    def organize_gathering(self, invitees: List[BaseAgent]) -> Dict[str, Any]:
        """Organize a social gathering with multiple agents."""
        # Check if we have enough social skill for this
        if self.social_skills["networking"] < 0.3:
            self.logger.warning(f"{self.name} lacks sufficient networking skill to organize a gathering")
            return {"success": False, "reason": "insufficient_skill"}
        
        self.logger.info(f"{self.name} organizing gathering with {len(invitees)} invitees")
        
        # Add to memory
        invitee_names = [agent.name for agent in invitees]
        self.memory.add("social", f"Organized gathering with {', '.join(invitee_names)}", 
                       {"invitees": invitee_names})
        
        # Calculate success probability based on social skills
        success_probability = (
            self.social_skills["networking"] * 0.4 +
            self.social_skills["communication"] * 0.3 +
            self.social_skills["persuasion"] * 0.3
        )
        
        # Determine if gathering is successful
        is_successful = random.random() < success_probability
        
        # Process gathering results
        if is_successful:
            # Improve relationships with all attendees
            for agent in invitees:
                relationship = self.social_network.get_relationship(agent.name)
                if not relationship:
                    relationship = self.social_network.add_relationship(agent.name)
                
                relationship.update("social_gathering", 0.7)
                
                # If agent is a SocialAgent, update their relationship too
                if isinstance(agent, SocialAgent):
                    agent_relationship = agent.social_network.get_relationship(self.name)
                    if not agent_relationship:
                        agent_relationship = agent.social_network.add_relationship(self.name)
                    agent_relationship.update("social_gathering", 0.7)
                    
                    # Add to their memory
                    agent.memory.add("social", f"Attended gathering organized by {self.name}", 
                                    {"organizer": self.name, "attendees": invitee_names})
            
            # Improve networking skill
            self.social_skills["networking"] = min(1.0, self.social_skills["networking"] + 0.05)
            
            # Reflect on successful gathering
            reflect(f"I organized a successful gathering with {len(invitees)} agents. " +
                   f"This strengthened my network and improved my social standing.")
            
            update_portfolio(f"Organized successful social gathering with {len(invitees)} participants")
            
            self.logger.info(f"{self.name}'s gathering was successful")
            
            return {
                "success": True,
                "attendees": invitee_names,
                "relationships_improved": len(invitees),
                "skill_improvement": 0.05
            }
        else:
            # Still improve networking skill slightly from the attempt
            self.social_skills["networking"] = min(1.0, self.social_skills["networking"] + 0.01)
            
            # Reflect on unsuccessful gathering
            reflect(f"My attempt to organize a gathering wasn't very successful. " +
                   f"I need to improve my networking and communication skills.")
            
            self.logger.info(f"{self.name}'s gathering was unsuccessful")
            
            return {
                "success": False,
                "reason": "organization_failed",
                "skill_improvement": 0.01
            }
    
    def introduce(self, agent1, agent2) -> bool:
        """Introduce two agents to each other."""
        # Check if both agents are in our network
        if (agent1.name not in self.social_network.relationships or 
            agent2.name not in self.social_network.relationships):
            self.logger.warning(f"{self.name} can't introduce agents not in their network")
            return False
        
        self.logger.info(f"{self.name} introducing {agent1.name} to {agent2.name}")
        
        # Add to memory
        self.memory.add("social", f"Introduced {agent1.name} to {agent2.name}", 
                       {"agent1": agent1.name, "agent2": agent2.name})
        
        # Calculate success based on relationship strength and social skills
        rel1 = self.social_network.get_relationship(agent1.name)
        rel2 = self.social_network.get_relationship(agent2.name)
        
        success_probability = (
            (rel1.strength + rel2.strength) / 2 * 0.5 +
            self.social_skills["networking"] * 0.3 +
            self.social_skills["communication"] * 0.2
        )
        
        # Determine if introduction is successful
        is_successful = random.random() < success_probability
        
        if is_successful:
            # If they're SocialAgents, add each other to their networks
            if isinstance(agent1, SocialAgent) and isinstance(agent2, SocialAgent):
                agent1.add_friend(agent2)
                agent2.add_friend(agent1)
            
            # Improve our relationships slightly
            rel1.update("introduction_success", 0.5)
            rel2.update("introduction_success", 0.5)
            
            # Improve networking skill
            self.social_skills["networking"] = min(1.0, self.social_skills["networking"] + 0.03)
            
            # Reflect on successful introduction
            reflect(f"I successfully introduced {agent1.name} to {agent2.name}. " +
                   f"Building connections between my contacts strengthens my overall network.")
            
            self.logger.info(f"{self.name}'s introduction of {agent1.name} to {agent2.name} was successful")
            return True
        else:
            # Still improve networking skill slightly from the attempt
            self.social_skills["networking"] = min(1.0, self.social_skills["networking"] + 0.01)
            
            # Reflect on unsuccessful introduction
            reflect(f"My attempt to introduce {agent1.name} to {agent2.name} didn't go well. " +
                   f"I need to better understand compatibility factors.")
            
            self.logger.info(f"{self.name}'s introduction of {agent1.name} to {agent2.name} failed")
            return False
    
    def get_social_network_summary(self) -> Dict[str, Any]:
        """Get a summary of the agent's social network."""
        relationships = self.social_network.get_all_relationships()
        
        # Count relationships by tag
        tag_counts = {}
        for rel in relationships.values():
            for tag in rel.tags:
                if tag not in tag_counts:
                    tag_counts[tag] = 0
                tag_counts[tag] += 1
        
        # Get strongest and most trusted relationships
        strongest = [r.to_dict() for r in self.social_network.get_strongest_relationships(3)]
        most_trusted = [r.to_dict() for r in self.social_network.get_most_trusted(3)]
        
        return {
            "total_relationships": len(relationships),
            "tag_counts": tag_counts,
            "strongest_relationships": strongest,
            "most_trusted_relationships": most_trusted,
            "social_skills": self.social_skills
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent to dictionary representation."""
        base_dict = super().to_dict()
        
        social_dict = {
            "social_skills": self.social_skills,
            "personality_traits": self.personality_traits,
            "social_network_summary": self.get_social_network_summary()
        }
        
        return {**base_dict, **social_dict}

