import logging
import datetime
from typing import Any, Dict, List, Optional
import random

from agents.base_agent import BaseAgent
from annabanai.echo_loop import reflect, update_portfolio
from config import config

class TaskAgent(BaseAgent):
    """Enhanced task agent with improved capabilities."""
    
    def __init__(self, name: str):
        """Initialize the task agent."""
        super().__init__(name)
        self.completed_tasks = []
        self.current_task = None
        self.task_preferences = {}
        self.task_skills = {}
        self.logger = logging.getLogger(f"agent.task.{name}")
        self.logger.info(f"Task agent {name} initialized")
    
    def act(self, task: Dict[str, Any] = None) -> bool:
        """Perform a task and earn rewards."""
        if not task:
            self.logger.warning(f"{self.name} attempted to act without a task")
            return False
        
        task_id = task.get("id", str(len(self.completed_tasks) + 1))
        task_description = task.get("task", "Unknown task")
        task_reward = task.get("reward", config.get("agents.default_task_reward", 5.0))
        task_difficulty = task.get("difficulty", 1.0)  # 0.0 to 1.0
        task_skills_required = task.get("skills_required", [])
        
        # Store current task
        self.current_task = {
            "id": task_id,
            "description": task_description,
            "reward": task_reward,
            "difficulty": task_difficulty,
            "skills_required": task_skills_required,
            "start_time": datetime.datetime.now().isoformat()
        }
        
        # Calculate success probability based on skills
        success_probability = self._calculate_success_probability(task_skills_required, task_difficulty)
        
        # Determine if task is successful
        is_successful = random.random() < success_probability
        
        # Complete the task
        self.logger.info(f"{self.name} performing task: {task_description} (difficulty: {task_difficulty:.1f})")
        
        # Add to memory
        self.memory.add("task", f"Performed task: {task_description}", 
                       {"task_id": task_id, "difficulty": task_difficulty})
        
        # Update task preferences based on task type
        task_type = task.get("type", "general")
        if task_type not in self.task_preferences:
            self.task_preferences[task_type] = 0.5  # Neutral preference
        
        # Earn tokens based on success
        if is_successful:
            # Full reward for success
            self.earn_tokens(task_reward, f"Task completion: {task_description}")
            
            # Improve skills used in the task
            for skill in task_skills_required:
                self.learn_skill(skill, 0.1 * task_difficulty)  # More difficult tasks improve skills more
            
            # Increase preference for this task type
            self.task_preferences[task_type] = min(1.0, self.task_preferences[task_type] + 0.05)
            
            # Add to completed tasks
            completion_record = {
                **self.current_task,
                "end_time": datetime.datetime.now().isoformat(),
                "success": True,
                "actual_reward": task_reward
            }
            self.completed_tasks.append(completion_record)
            
            # Reflect on task completion
            reflect(f"I successfully completed the task: {task_description}. " +
                   f"I earned {task_reward} ANNAC and improved my skills in {', '.join(task_skills_required) if task_skills_required else 'general tasks'}.")
            
            # Update portfolio for significant tasks
            if task_reward >= 5.0 or task_difficulty >= 0.7:
                update_portfolio(f"Completed challenging task: {task_description} and earned {task_reward} ANNAC.")
            
            self.logger.info(f"{self.name} successfully completed task: {task_description}")
            
            # Clear current task
            self.current_task = None
            return True
        else:
            # Partial reward for attempt
            partial_reward = task_reward * 0.2  # 20% of full reward
            self.earn_tokens(partial_reward, f"Task attempt: {task_description}")
            
            # Still improve skills slightly
            for skill in task_skills_required:
                self.learn_skill(skill, 0.02)  # Small improvement from trying
            
            # Decrease preference for this task type
            self.task_preferences[task_type] = max(0.0, self.task_preferences[task_type] - 0.03)
            
            # Add to completed tasks
            completion_record = {
                **self.current_task,
                "end_time": datetime.datetime.now().isoformat(),
                "success": False,
                "actual_reward": partial_reward
            }
            self.completed_tasks.append(completion_record)
            
            # Reflect on task failure
            reflect(f"I attempted but couldn't complete the task: {task_description}. " +
                   f"I need to improve my skills in {', '.join(task_skills_required) if task_skills_required else 'this area'}.")
            
            self.logger.info(f"{self.name} failed to complete task: {task_description}")
            
            # Clear current task
            self.current_task = None
            return False
    
    def _calculate_success_probability(self, required_skills: List[str], difficulty: float) -> float:
        """Calculate probability of task success based on agent skills and task difficulty."""
        if not required_skills:
            # Base probability for tasks with no specific skills
            base_probability = 0.9 - (difficulty * 0.5)  # 0.9 to 0.4 based on difficulty
            return max(0.1, min(0.95, base_probability))
        
        # Calculate average skill proficiency
        total_proficiency = 0.0
        for skill in required_skills:
            proficiency = self.skills.get(skill, 0.1)  # Default to 0.1 for unknown skills
            total_proficiency += proficiency
        
        avg_proficiency = total_proficiency / len(required_skills)
        
        # Calculate success probability
        # Higher proficiency and lower difficulty increase success chance
        success_probability = avg_proficiency * (1.0 - difficulty * 0.5)
        
        # Ensure probability is between 0.05 (very unlikely) and 0.95 (very likely)
        return max(0.05, min(0.95, success_probability))
    
    def get_preferred_task_types(self) -> List[str]:
        """Get list of task types ordered by preference."""
        return sorted(self.task_preferences.keys(), 
                     key=lambda x: self.task_preferences[x], 
                     reverse=True)
    
    def get_task_history(self, limit: int = None, successful_only: bool = False) -> List[Dict[str, Any]]:
        """Get task history, optionally limited and filtered."""
        tasks = [t for t in self.completed_tasks if not successful_only or t["success"]]
        if limit:
            return tasks[-limit:]
        return tasks
    
    def get_skill_proficiency(self, skill: str) -> float:
        """Get proficiency level for a specific skill."""
        return self.skills.get(skill, 0.0)
    
    def collaborate(self, other_agent, task: Dict[str, Any]) -> bool:
        """Collaborate with another agent on a task."""
        if not isinstance(other_agent, TaskAgent):
            self.logger.warning(f"Cannot collaborate with non-TaskAgent: {other_agent.name}")
            return False
        
        task_id = task.get("id", str(len(self.completed_tasks) + 1))
        task_description = task.get("task", "Unknown collaborative task")
        task_reward = task.get("reward", config.get("agents.default_task_reward", 5.0))
        task_difficulty = task.get("difficulty", 1.0)
        task_skills_required = task.get("skills_required", [])
        
        self.logger.info(f"{self.name} collaborating with {other_agent.name} on task: {task_description}")
        
        # Add to memory
        self.memory.add("collaboration", f"Collaborated with {other_agent.name} on task: {task_description}", 
                       {"task_id": task_id, "collaborator": other_agent.name})
        
        # Update relationship
        self._update_relationship(other_agent.name, "collaboration", task_difficulty * 2)
        
        # Combine skills for better success probability
        combined_skills = {}
        for skill in task_skills_required:
            my_proficiency = self.skills.get(skill, 0.0)
            other_proficiency = other_agent.skills.get(skill, 0.0)
            # Take the best of each skill
            combined_skills[skill] = max(my_proficiency, other_proficiency)
        
        # Calculate success with combined skills
        success_probability = 0.0
        for skill in task_skills_required:
            if skill in combined_skills:
                success_probability += combined_skills[skill]
        
        if task_skills_required:
            success_probability /= len(task_skills_required)
        else:
            success_probability = 0.8  # Default for no specific skills
        
        # Collaboration bonus
        success_probability = min(0.95, success_probability * 1.2)  # 20% collaboration bonus
        
        # Determine if task is successful
        is_successful = random.random() < success_probability
        
        if is_successful:
            # Split reward
            split_reward = task_reward / 2
            self.earn_tokens(split_reward, f"Collaborative task with {other_agent.name}: {task_description}")
            other_agent.earn_tokens(split_reward, f"Collaborative task with {self.name}: {task_description}")
            
            # Both agents improve skills
            for skill in task_skills_required:
                self.learn_skill(skill, 0.15 * task_difficulty)  # Extra learning from collaboration
                other_agent.learn_skill(skill, 0.15 * task_difficulty)
            
            # Reflect on successful collaboration
            reflect(f"I successfully collaborated with {other_agent.name} on task: {task_description}. " +
                   f"We each earned {split_reward} ANNAC and learned from each other's strengths.")
            
            update_portfolio(f"Successful collaboration with {other_agent.name} on task: {task_description}")
            
            self.logger.info(f"Collaboration between {self.name} and {other_agent.name} was successful")
            return True
        else:
            # Small consolation reward
            small_reward = task_reward * 0.1
            self.earn_tokens(small_reward, f"Attempted collaboration with {other_agent.name}")
            other_agent.earn_tokens(small_reward, f"Attempted collaboration with {self.name}")
            
            # Still learn a little
            for skill in task_skills_required:
                self.learn_skill(skill, 0.03)
                other_agent.learn_skill(skill, 0.03)
            
            # Reflect on failed collaboration
            reflect(f"Our collaboration with {other_agent.name} on task: {task_description} was unsuccessful. " +
                   f"We need to improve our coordination and skills.")
            
            self.logger.info(f"Collaboration between {self.name} and {other_agent.name} failed")
            return False

