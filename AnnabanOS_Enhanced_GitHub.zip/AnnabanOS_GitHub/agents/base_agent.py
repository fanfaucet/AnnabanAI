import logging
import datetime
from typing import Any, Dict, List, Optional, Tuple
import uuid

from config import config
from annabanai.echo_loop import reflect, update_portfolio

class Memory:
    """Memory class for storing and retrieving agent memories."""
    
    def __init__(self, capacity: int = None):
        """Initialize memory with optional capacity limit."""
        self.capacity = capacity or config.get("agents.memory_capacity", 100)
        self.memories = []
        self.logger = logging.getLogger(__name__)
    
    def add(self, memory_type: str, content: Any, metadata: Dict[str, Any] = None) -> None:
        """Add a memory with type, content, and optional metadata."""
        timestamp = datetime.datetime.now().isoformat()
        memory = {
            "id": str(uuid.uuid4()),
            "type": memory_type,
            "content": content,
            "timestamp": timestamp,
            "metadata": metadata or {}
        }
        
        self.memories.append(memory)
        
        # If over capacity, remove oldest memories
        if self.capacity and len(self.memories) > self.capacity:
            removed = self.memories.pop(0)
            self.logger.debug(f"Memory capacity reached. Removed memory: {removed['id']}")
    
    def get_by_type(self, memory_type: str) -> List[Dict[str, Any]]:
        """Retrieve memories of a specific type."""
        return [m for m in self.memories if m["type"] == memory_type]
    
    def get_recent(self, count: int = 10) -> List[Dict[str, Any]]:
        """Retrieve the most recent memories."""
        return self.memories[-count:] if count < len(self.memories) else self.memories
    
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Search memories for a query string."""
        results = []
        for memory in self.memories:
            content = str(memory["content"]).lower()
            if query.lower() in content:
                results.append(memory)
        return results
    
    def clear(self) -> None:
        """Clear all memories."""
        self.memories = []


class Goal:
    """Goal class for representing agent goals."""
    
    def __init__(self, description: str, priority: int = 1, deadline: Optional[str] = None):
        """Initialize a goal with description, priority, and optional deadline."""
        self.id = str(uuid.uuid4())
        self.description = description
        self.priority = priority  # 1 (lowest) to 5 (highest)
        self.deadline = deadline  # ISO format date string
        self.progress = 0.0  # 0.0 to 1.0
        self.completed = False
        self.created_at = datetime.datetime.now().isoformat()
        self.completed_at = None
    
    def update_progress(self, progress: float) -> None:
        """Update goal progress (0.0 to 1.0)."""
        self.progress = max(0.0, min(1.0, progress))
        if self.progress >= 1.0:
            self.complete()
    
    def complete(self) -> None:
        """Mark the goal as completed."""
        self.completed = True
        self.progress = 1.0
        self.completed_at = datetime.datetime.now().isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert goal to dictionary."""
        return {
            "id": self.id,
            "description": self.description,
            "priority": self.priority,
            "deadline": self.deadline,
            "progress": self.progress,
            "completed": self.completed,
            "created_at": self.created_at,
            "completed_at": self.completed_at
        }


class BaseAgent:
    """Enhanced base agent with improved capabilities."""
    
    def __init__(self, name: str):
        """Initialize the agent with a name."""
        self.name = name
        self.id = str(uuid.uuid4())
        self.wallet = config.get("token_economy.initial_balance", 0.0)
        self.memory = Memory(config.get("agents.memory_capacity"))
        self.profile = {}
        self.goals = []
        self.skills = {}
        self.relationships = {}
        self.logger = logging.getLogger(f"agent.{name}")
        self.transaction_history = []
        self.logger.info(f"Agent {name} initialized with ID {self.id}")
    
    def earn_tokens(self, amount: float, source: str = "system") -> None:
        """Earn tokens with transaction tracking."""
        if amount <= 0:
            self.logger.warning(f"Cannot earn non-positive amount: {amount}")
            return
            
        self.wallet += amount
        
        # Record transaction
        transaction = {
            "id": str(uuid.uuid4()),
            "type": "earn",
            "amount": amount,
            "source": source,
            "timestamp": datetime.datetime.now().isoformat(),
            "balance_after": self.wallet
        }
        self.transaction_history.append(transaction)
        
        # Add to memory
        self.memory.add("transaction", f"Earned {amount} ANNAC from {source}", 
                       {"transaction_id": transaction["id"], "amount": amount})
        
        self.logger.info(f"{self.name} earned {amount} ANNAC. Balance: {self.wallet}")
        
        # Reflect on significant earnings
        if amount >= 5.0:
            reflect(f"I earned {amount} ANNAC from {source}. This will help me achieve my goals.")
    
    def spend_tokens(self, amount: float, purpose: str = "unspecified") -> bool:
        """Spend tokens with transaction tracking and validation."""
        if amount <= 0:
            self.logger.warning(f"Cannot spend non-positive amount: {amount}")
            return False
            
        # Check minimum balance requirement
        min_balance = config.get("token_economy.minimum_balance", 0.0)
        if self.wallet - amount < min_balance:
            self.logger.warning(f"{self.name} tried to spend {amount}, but would fall below minimum balance {min_balance}")
            return False
            
        if self.wallet >= amount:
            self.wallet -= amount
            
            # Record transaction
            transaction = {
                "id": str(uuid.uuid4()),
                "type": "spend",
                "amount": amount,
                "purpose": purpose,
                "timestamp": datetime.datetime.now().isoformat(),
                "balance_after": self.wallet
            }
            self.transaction_history.append(transaction)
            
            # Add to memory
            self.memory.add("transaction", f"Spent {amount} ANNAC on {purpose}", 
                           {"transaction_id": transaction["id"], "amount": amount})
            
            self.logger.info(f"{self.name} spent {amount} ANNAC on {purpose}. Balance: {self.wallet}")
            return True
        else:
            self.logger.warning(f"{self.name} tried to spend {amount}, but only has {self.wallet}")
            return False
    
    def send_tokens(self, recipient, amount: float, memo: str = "") -> bool:
        """Send tokens to another agent with transaction tracking."""
        # Apply transaction fee if configured
        fee_rate = config.get("token_economy.transaction_fee", 0.0)
        fee = amount * fee_rate
        total_amount = amount + fee
        
        if self.spend_tokens(total_amount, f"Transfer to {recipient.name}" + (f": {memo}" if memo else "")):
            recipient.earn_tokens(amount, f"Transfer from {self.name}")
            
            # Record relationship strengthening
            self._update_relationship(recipient.name, "token_transfer", amount)
            
            # Add to memory
            self.memory.add("social", f"Sent {amount} ANNAC to {recipient.name}" + (f" with memo: {memo}" if memo else ""),
                           {"recipient": recipient.name, "amount": amount})
            
            self.logger.info(f"{self.name} sent {amount} ANNAC to {recipient.name}" + 
                            (f" (fee: {fee} ANNAC)" if fee > 0 else ""))
            
            # Reflect on significant transfers
            if amount >= 3.0:
                reflect(f"I sent {amount} ANNAC to {recipient.name}. " + 
                       f"This strengthens our relationship and helps achieve mutual goals.")
            
            return True
        return False
    
    def add_goal(self, description: str, priority: int = 1, deadline: Optional[str] = None) -> Goal:
        """Add a new goal for the agent."""
        goal = Goal(description, priority, deadline)
        self.goals.append(goal)
        
        # Add to memory
        self.memory.add("goal", f"Set new goal: {description}", 
                       {"goal_id": goal.id, "priority": priority})
        
        # Reflect on goal setting
        reflect(f"I set a new goal: {description}. This will help me focus my efforts and measure progress.")
        
        self.logger.info(f"{self.name} set new goal: {description} (priority: {priority})")
        return goal
    
    def update_goal_progress(self, goal_id: str, progress: float) -> None:
        """Update progress on a specific goal."""
        for goal in self.goals:
            if goal.id == goal_id:
                old_progress = goal.progress
                goal.update_progress(progress)
                
                # Add to memory if significant progress
                if goal.progress - old_progress >= 0.25:  # 25% progress milestone
                    self.memory.add("goal_progress", 
                                   f"Made progress on goal: {goal.description} ({int(goal.progress * 100)}% complete)",
                                   {"goal_id": goal.id, "progress": goal.progress})
                
                # Reflect on goal completion
                if goal.completed and not goal.completed_at:
                    reflect(f"I completed my goal: {goal.description}. This is a significant achievement.")
                    update_portfolio(f"Completed goal: {goal.description}")
                
                self.logger.info(f"{self.name} updated goal progress: {goal.description} to {goal.progress:.0%}")
                return
        
        self.logger.warning(f"Goal with ID {goal_id} not found")
    
    def get_active_goals(self) -> List[Dict[str, Any]]:
        """Get all active (non-completed) goals."""
        return [goal.to_dict() for goal in self.goals if not goal.completed]
    
    def get_completed_goals(self) -> List[Dict[str, Any]]:
        """Get all completed goals."""
        return [goal.to_dict() for goal in self.goals if goal.completed]
    
    def learn_skill(self, skill_name: str, proficiency_gain: float = 0.1) -> None:
        """Learn or improve a skill."""
        current_proficiency = self.skills.get(skill_name, 0.0)
        new_proficiency = min(1.0, current_proficiency + proficiency_gain)
        self.skills[skill_name] = new_proficiency
        
        # Add to memory
        self.memory.add("learning", f"Improved skill: {skill_name} to {new_proficiency:.0%} proficiency",
                       {"skill": skill_name, "proficiency": new_proficiency})
        
        # Reflect on significant skill improvements
        if new_proficiency >= 0.5 and current_proficiency < 0.5:  # Crossed 50% threshold
            reflect(f"I've reached an intermediate level in {skill_name}. I can now apply this skill effectively.")
            update_portfolio(f"Reached intermediate proficiency in {skill_name}")
        elif new_proficiency >= 0.9 and current_proficiency < 0.9:  # Crossed 90% threshold
            reflect(f"I've mastered {skill_name}. I can now use this skill at an expert level.")
            update_portfolio(f"Mastered {skill_name} skill")
        
        self.logger.info(f"{self.name} improved skill {skill_name} to {new_proficiency:.0%}")
    
    def _update_relationship(self, other_agent_name: str, interaction_type: str, value: float) -> None:
        """Update relationship strength with another agent."""
        if other_agent_name not in self.relationships:
            self.relationships[other_agent_name] = {
                "strength": 0.0,
                "interactions": 0,
                "last_interaction": None
            }
        
        relationship = self.relationships[other_agent_name]
        
        # Update relationship strength based on interaction
        influence_factor = config.get("agents.social_influence_factor", 0.5)
        if interaction_type == "token_transfer":
            # Normalize value impact based on wallet size
            normalized_value = min(1.0, value / (self.wallet + 0.1))  # Avoid division by zero
            strength_change = normalized_value * influence_factor
        else:
            strength_change = 0.05 * influence_factor  # Default small positive change
        
        relationship["strength"] = min(1.0, max(0.0, relationship["strength"] + strength_change))
        relationship["interactions"] += 1
        relationship["last_interaction"] = datetime.datetime.now().isoformat()
        
        self.logger.debug(f"Updated relationship with {other_agent_name} to strength {relationship['strength']:.2f}")
    
    def get_transaction_history(self, limit: int = None) -> List[Dict[str, Any]]:
        """Get transaction history, optionally limited to the most recent transactions."""
        if limit:
            return self.transaction_history[-limit:]
        return self.transaction_history
    
    def get_balance(self) -> float:
        """Get current token balance."""
        return self.wallet
    
    def get_memory_summary(self) -> Dict[str, int]:
        """Get summary of memory contents by type."""
        summary = {}
        for memory in self.memory.memories:
            memory_type = memory["type"]
            if memory_type not in summary:
                summary[memory_type] = 0
            summary[memory_type] += 1
        return summary
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "wallet": self.wallet,
            "profile": self.profile,
            "skills": self.skills,
            "goals": [goal.to_dict() for goal in self.goals],
            "relationships": self.relationships,
            "memory_summary": self.get_memory_summary()
        }

