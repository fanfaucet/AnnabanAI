import logging
import datetime
import random
from typing import Any, Dict, List, Optional, Tuple
import uuid

from agents.base_agent import BaseAgent
from agents.task_agent import TaskAgent
from agents.social_agent import SocialAgent
from annabanai.echo_loop import reflect, update_portfolio
from config import config

class AgentRole:
    """Class representing a specialized role for an agent in a collective."""
    
    def __init__(self, name: str, description: str, skills_required: List[str]):
        """Initialize a role with name, description, and required skills."""
        self.name = name
        self.description = description
        self.skills_required = skills_required
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert role to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "skills_required": self.skills_required
        }


class CollectiveTask:
    """Class representing a task for a collective to solve."""
    
    def __init__(self, description: str, difficulty: float, reward: float, 
                 required_roles: List[str] = None, deadline: Optional[str] = None):
        """Initialize a collective task."""
        self.id = str(uuid.uuid4())
        self.description = description
        self.difficulty = difficulty  # 0.0 to 1.0
        self.reward = reward
        self.required_roles = required_roles or []
        self.deadline = deadline  # ISO format date string
        self.status = "pending"  # pending, in_progress, completed, failed
        self.assigned_agents = {}  # role -> agent_id
        self.progress = 0.0  # 0.0 to 1.0
        self.created_at = datetime.datetime.now().isoformat()
        self.completed_at = None
        self.result = None
    
    def assign_agent(self, role: str, agent_id: str) -> bool:
        """Assign an agent to a role."""
        if role in self.required_roles:
            self.assigned_agents[role] = agent_id
            return True
        return False
    
    def is_fully_assigned(self) -> bool:
        """Check if all required roles are assigned."""
        return all(role in self.assigned_agents for role in self.required_roles)
    
    def update_progress(self, progress: float) -> None:
        """Update task progress."""
        self.progress = max(0.0, min(1.0, progress))
        if self.progress >= 1.0:
            self.complete()
    
    def start(self) -> None:
        """Mark the task as in progress."""
        self.status = "in_progress"
    
    def complete(self, result: Dict[str, Any] = None) -> None:
        """Mark the task as completed with optional result."""
        self.status = "completed"
        self.progress = 1.0
        self.completed_at = datetime.datetime.now().isoformat()
        self.result = result
    
    def fail(self, reason: str = None) -> None:
        """Mark the task as failed with optional reason."""
        self.status = "failed"
        self.completed_at = datetime.datetime.now().isoformat()
        self.result = {"failure_reason": reason} if reason else None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert task to dictionary."""
        return {
            "id": self.id,
            "description": self.description,
            "difficulty": self.difficulty,
            "reward": self.reward,
            "required_roles": self.required_roles,
            "deadline": self.deadline,
            "status": self.status,
            "assigned_agents": self.assigned_agents,
            "progress": self.progress,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "result": self.result
        }


class AgentCollective:
    """Class representing a collective of agents working together."""
    
    def __init__(self, name: str):
        """Initialize a collective with a name."""
        self.name = name
        self.id = str(uuid.uuid4())
        self.agents = {}  # agent_id -> agent
        self.roles = {}  # role_name -> AgentRole
        self.tasks = []  # List of CollectiveTask
        self.agent_roles = {}  # agent_id -> role_name
        self.token_pool = 0.0
        self.created_at = datetime.datetime.now().isoformat()
        self.logger = logging.getLogger(f"collective.{name}")
        self.logger.info(f"Agent collective {name} initialized with ID {self.id}")
        
        # Initialize standard roles
        self._initialize_standard_roles()
    
    def _initialize_standard_roles(self) -> None:
        """Initialize standard roles for the collective."""
        standard_roles = [
            AgentRole("coordinator", "Manages task allocation and coordination", 
                     ["leadership", "planning", "communication"]),
            AgentRole("analyst", "Analyzes data and provides insights", 
                     ["data_analysis", "critical_thinking", "problem_solving"]),
            AgentRole("creator", "Generates ideas and solutions", 
                     ["creativity", "innovation", "design_thinking"]),
            AgentRole("implementer", "Implements solutions and completes tasks", 
                     ["execution", "reliability", "technical_skills"]),
            AgentRole("evaluator", "Evaluates solutions and provides feedback", 
                     ["critical_thinking", "attention_to_detail", "evaluation"])
        ]
        
        for role in standard_roles:
            self.add_role(role)
    
    def add_agent(self, agent: BaseAgent, role: Optional[str] = None) -> bool:
        """Add an agent to the collective with an optional role."""
        if agent.id in self.agents:
            self.logger.warning(f"Agent {agent.name} is already in the collective")
            return False
        
        self.agents[agent.id] = agent
        
        if role and role in self.roles:
            self.agent_roles[agent.id] = role
        
        self.logger.info(f"Added agent {agent.name} to collective" + 
                        (f" with role {role}" if role else ""))
        return True
    
    def remove_agent(self, agent_id: str) -> bool:
        """Remove an agent from the collective."""
        if agent_id not in self.agents:
            self.logger.warning(f"Agent with ID {agent_id} is not in the collective")
            return False
        
        agent = self.agents[agent_id]
        del self.agents[agent_id]
        
        if agent_id in self.agent_roles:
            del self.agent_roles[agent_id]
        
        self.logger.info(f"Removed agent {agent.name} from collective")
        return True
    
    def add_role(self, role: AgentRole) -> bool:
        """Add a role to the collective."""
        if role.name in self.roles:
            self.logger.warning(f"Role {role.name} already exists in the collective")
            return False
        
        self.roles[role.name] = role
        self.logger.info(f"Added role {role.name} to collective")
        return True
    
    def assign_role(self, agent_id: str, role_name: str) -> bool:
        """Assign a role to an agent."""
        if agent_id not in self.agents:
            self.logger.warning(f"Agent with ID {agent_id} is not in the collective")
            return False
        
        if role_name not in self.roles:
            self.logger.warning(f"Role {role_name} does not exist in the collective")
            return False
        
        self.agent_roles[agent_id] = role_name
        agent = self.agents[agent_id]
        self.logger.info(f"Assigned role {role_name} to agent {agent.name}")
        return True
    
    def create_task(self, description: str, difficulty: float, reward: float, 
                   required_roles: List[str] = None, deadline: Optional[str] = None) -> CollectiveTask:
        """Create a new task for the collective."""
        task = CollectiveTask(description, difficulty, reward, required_roles, deadline)
        self.tasks.append(task)
        self.logger.info(f"Created task: {description} with difficulty {difficulty:.1f} and reward {reward}")
        return task
    
    def assign_task_roles(self, task_id: str) -> bool:
        """Automatically assign agents to task roles based on skills."""
        task = self._get_task_by_id(task_id)
        if not task:
            self.logger.warning(f"Task with ID {task_id} not found")
            return False
        
        if not task.required_roles:
            self.logger.warning(f"Task {task_id} has no required roles")
            return False
        
        # Find best agent for each role
        for role in task.required_roles:
            if role not in self.roles:
                self.logger.warning(f"Role {role} does not exist in the collective")
                continue
            
            required_skills = self.roles[role].skills_required
            best_agent_id = None
            best_score = -1
            
            # Find agents with this role
            role_agents = [agent_id for agent_id, agent_role in self.agent_roles.items() 
                          if agent_role == role]
            
            # Score each agent
            for agent_id in role_agents:
                agent = self.agents[agent_id]
                
                # Skip if already assigned to this task
                if agent_id in task.assigned_agents.values():
                    continue
                
                # Calculate skill match score
                score = 0
                for skill in required_skills:
                    if hasattr(agent, "skills") and isinstance(agent.skills, dict):
                        score += agent.skills.get(skill, 0.1)
                    else:
                        score += 0.1  # Default for agents without skills
                
                if score > best_score:
                    best_score = score
                    best_agent_id = agent_id
            
            # Assign best agent to role
            if best_agent_id:
                task.assign_agent(role, best_agent_id)
                agent = self.agents[best_agent_id]
                self.logger.info(f"Assigned agent {agent.name} to role {role} for task {task.description}")
            else:
                self.logger.warning(f"Could not find suitable agent for role {role}")
        
        return task.is_fully_assigned()
    
    def execute_task(self, task_id: str) -> Dict[str, Any]:
        """Execute a task with the assigned agents."""
        task = self._get_task_by_id(task_id)
        if not task:
            self.logger.warning(f"Task with ID {task_id} not found")
            return {"success": False, "reason": "task_not_found"}
        
        if not task.is_fully_assigned():
            self.logger.warning(f"Task {task_id} is not fully assigned")
            return {"success": False, "reason": "task_not_fully_assigned"}
        
        self.logger.info(f"Executing task: {task.description}")
        task.start()
        
        # Calculate success probability based on agent skills and task difficulty
        success_probability = self._calculate_task_success_probability(task)
        
        # Determine if task is successful
        is_successful = random.random() < success_probability
        
        if is_successful:
            # Task succeeded
            task.complete({"success": True, "quality": success_probability})
            
            # Distribute rewards
            self._distribute_task_rewards(task)
            
            # Improve agent skills
            self._improve_agent_skills_from_task(task)
            
            # Add to agent memories
            for role, agent_id in task.assigned_agents.items():
                agent = self.agents[agent_id]
                if hasattr(agent, "memory") and hasattr(agent.memory, "add"):
                    agent.memory.add("collective_task", 
                                    f"Successfully completed collective task: {task.description} in role {role}",
                                    {"task_id": task.id, "role": role, "collective": self.name})
            
            # Reflect on successful task
            for agent_id in task.assigned_agents.values():
                agent = self.agents[agent_id]
                if hasattr(agent, "name"):
                    reflect(f"As part of the {self.name} collective, I successfully completed the task: {task.description}. " +
                           f"Collaboration with other agents enhanced our effectiveness.")
            
            self.logger.info(f"Task {task.description} completed successfully")
            
            return {
                "success": True,
                "task_id": task.id,
                "quality": success_probability,
                "reward_distributed": task.reward
            }
        else:
            # Task failed
            task.fail("Insufficient collective capability")
            
            # Distribute small consolation rewards
            consolation_reward = task.reward * 0.2  # 20% of full reward
            self._distribute_task_rewards(task, consolation_reward)
            
            # Still improve skills slightly
            self._improve_agent_skills_from_task(task, 0.2)  # 20% of normal improvement
            
            # Add to agent memories
            for role, agent_id in task.assigned_agents.items():
                agent = self.agents[agent_id]
                if hasattr(agent, "memory") and hasattr(agent.memory, "add"):
                    agent.memory.add("collective_task", 
                                    f"Failed to complete collective task: {task.description} in role {role}",
                                    {"task_id": task.id, "role": role, "collective": self.name})
            
            # Reflect on failed task
            for agent_id in task.assigned_agents.values():
                agent = self.agents[agent_id]
                if hasattr(agent, "name"):
                    reflect(f"Our collective attempt at the task: {task.description} was unsuccessful. " +
                           f"We need to improve our coordination and skills.")
            
            self.logger.info(f"Task {task.description} failed")
            
            return {
                "success": False,
                "task_id": task.id,
                "reason": "execution_failed",
                "consolation_reward": consolation_reward
            }
    
    def _calculate_task_success_probability(self, task: CollectiveTask) -> float:
        """Calculate probability of task success based on assigned agents' skills."""
        if not task.is_fully_assigned():
            return 0.0
        
        total_skill_match = 0.0
        
        for role, agent_id in task.assigned_agents.items():
            agent = self.agents[agent_id]
            role_obj = self.roles.get(role)
            
            if not role_obj:
                continue
            
            # Calculate skill match for this role
            skill_match = 0.0
            for skill in role_obj.skills_required:
                if hasattr(agent, "skills") and isinstance(agent.skills, dict):
                    skill_match += agent.skills.get(skill, 0.1)
                else:
                    skill_match += 0.1  # Default for agents without skills
            
            # Average skill match for this role
            if role_obj.skills_required:
                skill_match /= len(role_obj.skills_required)
            else:
                skill_match = 0.5  # Default for roles without required skills
            
            total_skill_match += skill_match
        
        # Average skill match across all roles
        avg_skill_match = total_skill_match / len(task.assigned_agents) if task.assigned_agents else 0.0
        
        # Calculate success probability based on skill match and task difficulty
        success_probability = avg_skill_match * (1.0 - task.difficulty * 0.5)
        
        # Collaboration bonus
        num_agents = len(task.assigned_agents)
        if num_agents >= 3:
            collaboration_bonus = 0.1  # 10% bonus for 3+ agents
            success_probability = min(0.95, success_probability + collaboration_bonus)
        
        # Ensure probability is between 0.05 (very unlikely) and 0.95 (very likely)
        return max(0.05, min(0.95, success_probability))
    
    def _distribute_task_rewards(self, task: CollectiveTask, override_reward: float = None) -> None:
        """Distribute rewards to agents who completed the task."""
        reward = override_reward if override_reward is not None else task.reward
        
        # Determine number of agents to split reward among
        num_agents = len(task.assigned_agents)
        if num_agents == 0:
            return
        
        # Calculate individual reward
        individual_reward = reward / num_agents
        
        # Distribute rewards
        for agent_id in task.assigned_agents.values():
            agent = self.agents[agent_id]
            if hasattr(agent, "earn_tokens"):
                agent.earn_tokens(individual_reward, f"Collective task: {task.description}")
    
    def _improve_agent_skills_from_task(self, task: CollectiveTask, multiplier: float = 1.0) -> None:
        """Improve agent skills based on task completion."""
        for role, agent_id in task.assigned_agents.items():
            agent = self.agents[agent_id]
            role_obj = self.roles.get(role)
            
            if not role_obj or not hasattr(agent, "learn_skill"):
                continue
            
            # Improve skills required for this role
            for skill in role_obj.skills_required:
                improvement = 0.05 * task.difficulty * multiplier
                agent.learn_skill(skill, improvement)
    
    def _get_task_by_id(self, task_id: str) -> Optional[CollectiveTask]:
        """Get a task by its ID."""
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None
    
    def get_agent_by_role(self, role: str) -> List[BaseAgent]:
        """Get all agents with a specific role."""
        agents = []
        for agent_id, agent_role in self.agent_roles.items():
            if agent_role == role and agent_id in self.agents:
                agents.append(self.agents[agent_id])
        return agents
    
    def get_active_tasks(self) -> List[Dict[str, Any]]:
        """Get all active (non-completed) tasks."""
        return [task.to_dict() for task in self.tasks 
               if task.status in ["pending", "in_progress"]]
    
    def get_completed_tasks(self) -> List[Dict[str, Any]]:
        """Get all completed tasks."""
        return [task.to_dict() for task in self.tasks 
               if task.status == "completed"]
    
    def get_failed_tasks(self) -> List[Dict[str, Any]]:
        """Get all failed tasks."""
        return [task.to_dict() for task in self.tasks 
               if task.status == "failed"]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert collective to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "agents": {agent_id: agent.name for agent_id, agent in self.agents.items()},
            "roles": {name: role.to_dict() for name, role in self.roles.items()},
            "agent_roles": self.agent_roles,
            "active_tasks": len(self.get_active_tasks()),
            "completed_tasks": len(self.get_completed_tasks()),
            "failed_tasks": len(self.get_failed_tasks()),
            "created_at": self.created_at
        }

